# Dayflow Feature Documentation and System Architecture Report

**Author:** Manus AI  
**Project:** Dayflow — Human Resource Management System  
**Report scope:** Current implementation in `dayflow-odoo-nmit`

## 1. Executive summary

Dayflow is a role-aware workforce management portal that connects employee self-service and HR operations in one workspace. Its core domains are employee profiles, attendance, leave and time-off, payroll, notifications, and Workforce Pulse. The product emphasizes explainability: operational signals are presented with visible evidence and recommended human actions rather than opaque employee scoring.[1]

The portal also treats connectivity as part of the product experience. It caches the latest successful dashboard payload, labels cached content as read-only, reports Live, Syncing, or Offline status, retries transient failures, exposes a manual refresh action, and announces restored live data with a toast and visual transition. The implementation therefore supports continuity without misrepresenting stale records as current.

## 2. Feature inventory

| Capability | Current behavior | Primary users |
|---|---|---|
| Secure access | Manus OAuth entry point, session loading, logout, authenticated redirect, and friendly recovery for cancelled, denied, expired, or invalid sessions. | All users |
| Organization entry | Branded login page, organization/workspace selector, selected-workspace persistence before OAuth, and security messaging. | All users |
| Role-aware workspace | HR/admin and employee viewing modes with different navigation and data scopes. | HR, employees |
| Employee directory | Searchable people directory, profile context, department information, and add-employee entry point. | HR |
| Attendance | Check-in/out, work-minute calculation, weekly rhythm, calendar context, recent records, team attendance, and empty-state handling. | HR, employees |
| Leave and time-off | Paid, sick, and unpaid requests, date validation, overlap protection, balances, request history, review actions, and status updates. | HR, employees |
| Payroll | Salary components, net-pay calculation, latest pay month, readiness percentage, employee read-only view, and HR team view. | HR, employees |
| Notifications | Persisted notifications, unread count, individual read action, mark-all-read, and event creation from leave and attendance workflows. | HR, employees |
| Workforce Pulse | Evidence-backed operational cues derived from attendance, time-off, and workload data. It is aggregate-first and does not diagnose, rank, or profile people. | HR |
| Admin onboarding | Persistent first-login checklist covering workspace confirmation, first employee, attendance connection, and time-off policy review. | First-time administrators |
| Theme and visual system | Persisted light/dark preference, colorful metric gradients, hover lift, chart entrance motion, reconnect transition, ambient surfaces, and reduced-motion fallbacks. | All users |
| Offline resilience | Cached dashboard snapshot, last-synced time, read-only offline mode, bounded retries, reconnect messaging, manual refresh, and restored-live-data toast. | All users |

## 3. Role and permission model

The built-in `users` table identifies the authenticated session and includes a `role` enum with `user` and `admin` values. The application maps the admin role to the HR workspace and protects team-level procedures through `adminProcedure`. Employees use `protectedProcedure` for their own records, while HR receives scoped team reads.[1] [2]

| Operation | Employee | Admin/HR |
|---|---:|---:|
| Read own employee profile | Yes | Yes |
| Read employee directory | No | Yes |
| Read own attendance | Yes | Yes |
| Read team attendance | No | Yes |
| Check in/out | Yes | Available through protected flow |
| Create leave request | Yes | Available through protected flow |
| Review leave request | No | Yes |
| Read own payroll | Yes | Yes |
| Read team payroll | No | Yes |
| Read Workforce Pulse | No | Yes |
| Read and update notification state | Yes | Yes |

## 4. Domain data model

The database schema uses Drizzle ORM with MySQL-compatible tables. The principal entities are `users`, `employees`, `attendance`, `leaveRequests`, `payroll`, `notifications`, and `pulseSignals`.[2]

| Entity | Important fields | Purpose |
|---|---|---|
| `users` | `id`, `openId`, `name`, `email`, `role`, timestamps | Authenticated identity and authorization role. |
| `employees` | employee identity, department, job title, user link, profile metadata | Workforce directory and employee context. |
| `attendance` | employee link, work date, check-in/out, status, work minutes | Daily attendance and hours evidence. |
| `leaveRequests` | employee link, type, date range, days, status, remarks, HR comment | Time-off lifecycle and review workflow. |
| `payroll` | employee link, pay month, basic, HRA, benefits, deductions, net pay | Salary visibility and payroll readiness. |
| `notifications` | user scope, title, body, type, created timestamp, nullable read timestamp | In-app event inbox and unread state. |
| `pulseSignals` | signal type, visibility, title, evidence, recommendation | Explainable aggregate operational cues. |

The shared domain module contains pure calculations for work minutes, inclusive leave days, leave-overlap protection, net pay, and dashboard aggregation. Keeping these calculations outside the database adapter makes important business rules independently testable.[3]

## 5. Application architecture

Dayflow follows the Manus full-stack template: React 19 and Tailwind CSS provide the client UI; Express hosts the application; tRPC supplies typed client/server procedures; Drizzle maps the relational schema; and Manus OAuth supplies authentication.[1]

```mermaid
flowchart LR
  Browser[React portal] --> Router[Wouter routes]
  Router --> Login[Branded login]
  Router --> Home[Authenticated Home shell]
  Home --> Hooks[tRPC React hooks]
  Hooks --> API[tRPC procedures]
  API --> Auth[Manus OAuth/session context]
  API --> DBHelpers[server/db.ts helpers]
  DBHelpers --> Drizzle[Drizzle ORM]
  Drizzle --> MySQL[(MySQL/TiDB database)]
  Home --> Cache[Browser cache/localStorage]
  Cache --> Offline[Read-only offline fallback]
  DBHelpers --> Events[Leave and attendance notification events]
  Events --> MySQL
```

### Client layer

`client/src/App.tsx` owns the route shell and wraps the application with the theme provider, tooltip provider, toaster, and error boundary. The `/login` route renders the branded pre-auth experience; `/` renders the authenticated portal shell. `Home.tsx` coordinates role switching, dashboard queries, notification queries, cache hydration, online/offline listeners, reconnect state, manual refresh, theme controls, onboarding, and feature-page composition.[4] [5]

The theme context stores the selected light/dark mode in browser storage when switching is enabled and applies the corresponding root class. CSS variables and layered gradients provide the visual system, while `prefers-reduced-motion` disables nonessential animation.[6]

### Server layer

`server/routers.ts` exposes typed procedures grouped by domain. The dashboard query resolves the authenticated employee context, applies admin-versus-employee scope, and delegates aggregation to database helpers. Notification procedures list scoped items and mutate individual or global read state. Employee, attendance, leave, payroll, and pulse procedures are protected according to their access needs.[7]

`server/db.ts` is the data-access and orchestration layer. It assembles dashboard payloads from live rows, calls shared aggregation functions, persists notifications, and creates meaningful notification events when attendance check-in/out or leave submission/review occurs. The server does not need to know about the client’s visual cache; it returns typed data and the client decides whether to present live or clearly labeled cached content.[8]

## 6. Live dashboard data flow

The dashboard uses a single typed source query for the main metric payload. The payload contains employee records, attendance rows, leave requests, payroll rows, and derived metrics. The client derives `liveDashboard` from the most recent live response or the cached snapshot when the live response is unavailable.

The primary connection state is represented by three modes:

| Mode | Meaning | User-facing treatment |
|---|---|---|
| `live` | The current query is available and no offline condition is active. | Live indicator and normal interactive workspace. |
| `reconnecting` | A protected request is actively refetching after a failure or connection transition. | Syncing indicator, reconnect message, and retry action. |
| `offline` | The browser is offline or a cached snapshot is being used after an error. | Read-only label, cached-data message, freshness timestamp, and refresh action. |

The dashboard intentionally separates initial loading from refetching. Initial loading can show a structured loading state. During reconnecting, cached content can remain visible instead of disappearing, so the user retains context while the request is retried.

## 7. Offline resilience and recovery

The client stores the latest successful dashboard snapshot in browser storage and stores a timestamp beside it. Cache access is defensive: unavailable storage, malformed JSON, or missing keys resolve to an empty cache rather than breaking the page. Cached content is never labeled as live.

Protected dashboard and notification queries are gated on authentication and use bounded automatic retries with exponential delay. If automatic retries do not recover the request, the user can press Refresh or Retry now. The browser listens for online and offline transitions. When the connection returns and the effective state changes from reconnecting or offline to live, Dayflow displays a “Live data restored” toast and triggers a short dashboard flash/lift transition. Reduced-motion preferences suppress the visual transition while preserving the status and toast information.

The offline mode is read-only by design. Write operations such as check-in, check-out, leave submission, or leave review should be performed after live connectivity returns so the system does not imply that a mutation succeeded while disconnected.

## 8. Notifications and event model

Notifications are scoped to the authenticated user and include a title, body, type, creation time, and nullable read timestamp. The notification center displays an unread badge, visually distinguishes unread items, supports per-item read actions, and supports mark-all-as-read. Backend mutations enforce the user scope before changing read state.[2] [8]

Meaningful events create notifications at the point where the related record is written. Attendance check-in and check-out can create activity messages, while leave submission and HR review can create user-facing workflow updates. This avoids fabricated activity and keeps inbox content tied to real domain events.

## 9. Authentication and sign-in experience

The login route uses the existing `startLogin` OAuth launcher rather than manually managing session cookies. Before launching OAuth, the page persists the selected organization workspace. An authenticated user is redirected to the portal root. The page maps common failure query parameters into friendly copy: cancellation or denial invites another attempt, expired or invalid state suggests starting a fresh sign-in, and generic session errors offer a retry path.

The sign-in UI communicates organization context through a branded workspace selector. The current implementation presents a local workspace list for the portal experience; a production extension should replace that list with organization records returned from a trusted backend scope.

## 10. First-login administrator onboarding

The admin checklist is a client-side persistent progress layer for the first workspace setup. It contains four steps: confirm the workspace, add the first employee, connect attendance records, and review the time-off policy. Each step can be toggled, the percentage is recalculated immediately, and the progress array is stored in browser storage. Completion writes a separate onboarding-complete marker so the initial checklist does not interrupt later sessions, while the setup checklist entry remains reopenable from the portal.

The checklist is intentionally a guide rather than a replacement for the underlying workflows. Each step should eventually open the related setup view or mutation flow, allowing the checklist to become a true navigation layer for first-time administrators.

## 11. Visual and interaction system

Dayflow uses a calm operational palette with distinct accent families for people, time, leave, and payroll. The authenticated shell adds lavender-mint ambient washes, translucent top-bar depth, soft metric-card shadows, colorful gradient surfaces, and a more editorial hierarchy for greetings and section labels. Metric cards lift slightly on hover, charts animate their bars on entry, and the reconnect state uses a brief success flash when live data returns.

Motion is limited to transform and opacity where possible. Interaction durations are short, and the stylesheet includes reduced-motion fallbacks so accessibility preferences take precedence over decorative effects. Status labels do not depend on color alone: the interface also uses words such as Live, Syncing, Offline, and read-only messaging.

## 12. Validation and test coverage

The project’s validation commands are:

```bash
pnpm check
pnpm test
```

The current suite covers authentication logout, dashboard aggregation, permissions, notification and fetch resilience contracts, offline cache behavior, connection-mode decisions, reconnect-success and freshness helpers, login state and rendered login output, workspace persistence ordering, onboarding progress persistence, and motion-style contracts. The latest verified run reports 20 passing tests across 9 test files.

The browser verification pass includes the authenticated dashboard, the onboarding checklist modal, responsive behavior, and the login route’s authenticated redirect behavior. In an authenticated preview, navigating to `/login` correctly returns to `/`; the unauthenticated login surface is covered by rendered component tests and can be reviewed after signing out or using a clean browser session.

## 13. Production considerations and roadmap

The current architecture is prepared for a production-backed HR portal, but several extensions would improve operational completeness. Organization selection should be backed by a server-authorized workspace table rather than a local list. Onboarding checklist actions should deep-link into real setup forms. Offline mutations should either remain disabled or use an explicit queued-action design with conflict resolution. Notification preferences, audit history, downloadable payslips, attendance exports, email verification, and configurable organization policies are natural next steps.

The privacy boundary around Workforce Pulse should remain intact as the product grows. Signals should continue to be traceable to operational evidence, should avoid sensitive individual inference, and should leave the final decision with a human owner.

## References

[1]: ./README.md "Dayflow project README and feature map"
[2]: ./drizzle/schema.ts "Dayflow Drizzle database schema"
[3]: ./shared/dayflow.ts "Dayflow shared domain calculations and resilience helpers"
[4]: ./client/src/App.tsx "Dayflow application routes and providers"
[5]: ./client/src/pages/Home.tsx "Dayflow authenticated portal shell and feature views"
[6]: ./client/src/contexts/ThemeContext.tsx "Dayflow theme persistence and root theme handling"
[7]: ./server/routers.ts "Dayflow typed tRPC procedures and authorization boundaries"
[8]: ./server/db.ts "Dayflow database access, dashboard aggregation, and notification events"
