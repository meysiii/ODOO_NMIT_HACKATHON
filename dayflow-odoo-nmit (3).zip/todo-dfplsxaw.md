# Project TODO

- [x] Review the current Dayflow portal layout, theme, and reusable components
- [x] Establish a cohesive visual direction for the portal enhancement
- [x] Upgrade the portal shell with polished styling, depth, and graphical effects
- [x] Refine key interactive states and responsive behavior without changing core functionality
- [x] Add or update Vitest coverage for the implemented UI behavior where practical
- [x] Run type checks, tests, and visual verification; fix any regressions
- [x] Save a checkpoint containing the completed portal enhancement

- [x] Add live employee, attendance, leave, and payroll data models and backend queries
- [x] Replace dashboard demo metrics with live backend data and loading/error states
- [x] Add persisted theme preference control with refined dark mode styling
- [x] Implement notification persistence, read/unread mutations, and notification center UI
- [x] Add Vitest coverage for live data, theme preference, and notification behavior
- [x] Run type checks, tests, and responsive visual verification for the new features
- [x] Save a checkpoint containing the connected portal features

- [x] Replace remaining hardcoded employee, attendance, leave, payroll, and pulse metrics with live scoped tRPC data
- [x] Add explicit dashboard loading, error, and empty states
- [x] Create notifications from leave and attendance events so the inbox receives real updates
- [x] Add unit coverage for aggregate calculations, theme persistence, and notification read-state behavior
- [x] Verify light mode, dark mode, mobile layout, and notification interactions in the browser

- [x] Add a clear dashboard loading skeleton and explicit no-live-data empty state
- [x] Create notifications for attendance check-in and check-out events
- [x] Add direct unit coverage for dashboard aggregates, theme persistence, and notification state transitions

- [x] Replace the AttendanceWeek static chart with live attendance aggregates
- [x] Refactor the selected-person panel to use live employee, payroll, and leave data
- [x] Replace hardcoded attendance calendar and detail values with scoped live attendance datas
- [x] Replace hardcoded leave balances and request rows with live leave data
- [x] Replace remaining payroll notes, meta totals, and component values with live payroll data

- [x] Replace remaining AttendanceView calendar markers, progress, start/target, and record labels with values derived from live attendance records
- [x] Map LeaveView request rows directly from live leaveRequests
- [x] Replace remaining PayrollView readiness and deposit copy with live payroll metrics or neutral empty-state copy

- [x] Replace attendance calendar markers and selected-day metadata with live attendance-derived values
- [x] Replace employee-mode recent attendance labels with live records and an explicit empty state

- [x] Derive AttendanceView selected day and period metadata from live attendance records
- [x] Add an explicit empty state for an empty recent-attendance list

- [x] Diagnose the failed tRPC API fetch on the overview page
- [x] Fix the underlying client or backend runtime issue without regressing live metrics
- [x] Add or update regression coverage for the failed API path
- [x] Re-run checks, inspect runtime logs, and verify the overview page
- [x] Save a checkpoint containing the bug fix

- [x] Add visible dashboard reconnect status and retry feedback
- [x] Cache the latest dashboard payload for a read-only offline fallback
- [x] Add a manual dashboard refresh action with clear loading and failure states
- [x] Enrich the Dayflow portal with a more colorful, attractive, accessible accent system
- [x] Add regression coverage for offline fallback, refresh behavior, and reconnect feedback
- [x] Run type checks, tests, and responsive visual verification
- [x] Save a checkpoint containing the resilience and visual enhancements

- [x] Add regression coverage for dashboard offline cache fallback, reconnect status messaging, and manual refresh behavior

- [x] Extract executable dashboard cache hydration/persistence helpers
- [x] Add behavior-level tests for offline fallback, reconnect mode, and manual refresh intent

- [x] Add animated reconnect-success transition and success toast
- [x] Add top-bar offline indicator and cached-data last-synced timestamp
- [x] Add interactive gradient-card hover effects and smooth chart loading animations
- [x] Create a reusable skill capturing this Dayflow resilience and visual-enhancement workflow
- [x] Add regression coverage for reconnect success, cache freshness, and motion contracts
- [x] Run type checks, tests, visual verification, and skill validation
- [x] Save a checkpoint containing the portal enhancements

- [x] Add executable coverage for reconnect-success detection and last-synced freshness formatting

- [x] Tie a visible reconnect-success animation to the live connection restoration state
- [x] Add regression assertions for gradient-card hover and chart loading animation contracts
- [x] Mark and save the final portal-enhancement checkpoint after successful validation

- [x] Add a Dayflow login route with colorful branded layout
- [x] Wire the login action to the existing Manus OAuth flow
- [x] Add authenticated redirect behavior and loading/error states
- [x] Add responsive login styling and visual effects consistent with the portal
- [x] Add regression coverage for login routing and auth entry behavior
- [x] Run type checks, tests, and browser visual verification
- [x] Save a checkpoint containing the login page

- [x] Add executable login behavior coverage beyond source-string assertions
- [x] Save a new checkpoint after the login page changes are validated

- [x] Add first-login administrator onboarding checklist with persistent progress
- [x] Add friendly handling for cancelled or expired OAuth sessions
- [x] Add organization branding and workspace selection to the sign-in journey
- [x] Refine the portal into a more elegant, distinctive theme beyond the plain dashboard treatment
- [x] Update and validate the reusable Dayflow portal enhancement skill
- [x] Add regression coverage for onboarding, OAuth recovery, and workspace selection
- [x] Run type checks, tests, and visual verification
- [x] Save a checkpoint containing the enhanced sign-in and onboarding flow

- [x] Add an elegant authenticated portal-shell refinement beyond the sign-in page
- [x] Add executable onboarding persistence, workspace selection, and OAuth recovery coverage
- [x] Perform fresh visual verification of login and onboarding states
- [x] Save a new checkpoint after the latest onboarding and sign-in changes

- [x] Add behavior-level coverage for workspace selection persistence before OAuth launch
- [x] Add storage-backed onboarding checklist persistence coverage
- [x] Open and visually verify the onboarding checklist after the latest changes
- [x] Save a new checkpoint after the latest sign-in and onboarding refinements

- [x] Add an executable workspace-aware login action test that verifies persistence happens before OAuth launch
- [x] Capture explicit visual evidence of the opened admin onboarding checklist state
- [x] Save the final checkpoint only after these latest sign-in refinements are included

- [x] Make unauthenticated root access show the login page first
- [x] Add Employee and HR login modes with email or employee-ID credential fields
- [x] Add secure password-based login and session handling
- [x] Add new-account creation flow with role-aware validation
- [x] Preserve or clearly separate the existing OAuth entry flow
- [x] Add authentication regression coverage for login, signup, roles, and routing
- [x] Run type checks, tests, and responsive browser verification
- [x] Save a checkpoint containing the login-first portal

- [x] Prevent the portal shell from rendering before unauthenticated users reach the login route
- [x] Restrict HR account creation to an explicit invite or admin approval path
- [x] Add executable tests for credential sign-up/sign-in, role enforcement, cookie issuance, and root routing
- [x] Capture fresh desktop and mobile screenshots of sign-in and account creation
- [x] Save a checkpoint after the login-first flow is fully validated

- [x] Align the email or employee-ID and password fields into separate clear boxes
- [x] Add prominent HR and Employee selectors at the top of the login experience
- [x] Add dedicated HR and Employee login routes with role-specific form state
- [x] Redirect each role through its correct authenticated portal context
- [x] Add regression coverage for route selection and aligned login structure
- [x] Run type checks, tests, and desktop/mobile visual verification
- [x] Save a checkpoint containing the corrected login flow

- [x] Lock the authenticated portal role to the signed-in account and prevent cross-role switching
- [x] Add executable route-mode and aligned-field behavior coverage
- [x] Capture fresh desktop and mobile verification from the correct Dayflow preview
- [x] Save a checkpoint after resolving the validation gaps

- [x] Replace the visible Maya Iyer HR identity with the neutral HR Manager label
- [x] Add 50 employee directory records without changing existing production records
- [x] Create the requested employee profile and secure credential login for meysintha2006@gmail.com
- [x] Add regression coverage for the updated HR label and employee dataset
- [x] Verify employee directory counts and credential sign-in behavior
- [x] Save a checkpoint containing the employee data and HR label update

- [x] Add database-backed regression coverage for the 50 seeded employees and Meisintha’s employee record
- [x] Verify the requested employee password against the stored scrypt credential format
- [x] Complete the HR identity and employee dataset update checkpoint
