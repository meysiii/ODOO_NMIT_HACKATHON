import { useMemo, useState } from "react";
import { ArrowRight, Check, Circle, Sparkles, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { persistChecklistProgress, readChecklistProgress, toggleChecklistItem } from "@shared/dayflow";

const checklist = [
  { id: "workspace", title: "Confirm your workspace", detail: "Set the right organization name and people context." },
  { id: "people", title: "Add your first employee", detail: "Create one profile so live people metrics can begin." },
  { id: "attendance", title: "Connect attendance records", detail: "Give your team a reliable daily rhythm to review." },
  { id: "leave", title: "Review time-off policy", detail: "Make approvals and balances easy to understand." },
];

export default function AdminOnboardingChecklist({ onClose }: { onClose: () => void }) {
  const [completed, setCompleted] = useState<string[]>(() => readChecklistProgress(window.localStorage));
  const remaining = checklist.length - completed.length;
  const progress = useMemo(() => Math.round((completed.length / checklist.length) * 100), [completed.length]);
  const toggle = (id: string) => {
    const next = toggleChecklistItem(completed, id);
    setCompleted(next);
    persistChecklistProgress(window.localStorage, next);
  };

  return <div className="modal-backdrop"><div className="admin-checklist-modal" role="dialog" aria-modal="true" aria-labelledby="admin-checklist-title">
    <button className="modal-close" onClick={onClose} aria-label="Close onboarding"><X size={18} /></button>
    <div className="admin-checklist-orb"><Sparkles size={23} /></div>
    <div className="modal-kicker">YOUR FIRST FLOW</div>
    <h2 id="admin-checklist-title">Set up your people workspace.</h2>
    <p>Take a few small steps to make Dayflow useful from the first morning. You can return to these anytime.</p>
    <div className="checklist-progress"><span><b>{completed.length} of {checklist.length}</b> complete</span><strong>{progress}%</strong><div><i style={{ width: `${progress}%` }} /></div></div>
    <div className="admin-checklist-list">{checklist.map((item) => { const done = completed.includes(item.id); return <button className={`admin-checklist-item ${done ? "done" : ""}`} key={item.id} onClick={() => toggle(item.id)}><span className="checklist-check">{done ? <Check size={14} /> : <Circle size={13} />}</span><span><strong>{item.title}</strong><small>{item.detail}</small></span><ArrowRight size={15} /></button>; })}</div>
    <div className="modal-actions"><span className="checklist-hint">{remaining ? `${remaining} step${remaining > 1 ? "s" : ""} to go` : "Your workspace is ready"}</span><Button className="primary-button" onClick={onClose}>{remaining ? "I’ll do this later" : "Start using Dayflow"} <ArrowRight size={15} /></Button></div>
  </div></div>;
}
