import React, { useEffect, useMemo, useState } from "react";
import { ArrowRight, Building2, Check, ChevronDown, Loader2, ShieldCheck, Sparkles } from "lucide-react";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getAuthRecoveryMessage, getLoginDestination, runWorkspaceLogin } from "@shared/dayflow";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";

const workspaces = [
  { name: "Northstar Labs", detail: "People workspace", initials: "N", color: "#7867e8" },
  { name: "Lumen Studio", detail: "People workspace", initials: "L", color: "#41b889" },
];

type LoginMode = "employee" | "hr";

type LoginProps = { defaultMode?: LoginMode };

export default function Login({ defaultMode = "employee" }: LoginProps) {
  const { user, loading, error } = useAuth();
  const [, setLocation] = useLocation();
  const [mode, setMode] = useState<LoginMode>(defaultMode);
  const [isCreateAccount, setIsCreateAccount] = useState(false);
  const [selectedWorkspace, setSelectedWorkspace] = useState(workspaces[0]);
  const [workspaceOpen, setWorkspaceOpen] = useState(false);

  useEffect(() => setMode(defaultMode), [defaultMode]);
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [employeeId, setEmployeeId] = useState("");
  const [formMessage, setFormMessage] = useState("");
  const signIn = trpc.auth.credentialSignIn.useMutation({ onSuccess: () => setLocation("/") });
  const signUp = trpc.auth.credentialSignUp.useMutation({ onSuccess: () => { setIsCreateAccount(false); setFormMessage("Account created. You can now sign in with your credentials."); } });
  const authMessage = useMemo(() => {
    const params = new URLSearchParams(typeof window === "undefined" ? "" : window.location.search);
    const reason = params.get("error") ?? params.get("error_description") ?? "";
    return getAuthRecoveryMessage(reason, Boolean(error));
  }, [error]);

  useEffect(() => {
    if (user && getLoginDestination(Boolean(user)) === "/") setLocation("/");
  }, [setLocation, user]);

  const handleModeChange = (next: LoginMode) => { setMode(next); setLocation(`/login/${next}`); };
  const handleOAuth = () => runWorkspaceLogin(window.localStorage, selectedWorkspace.name, startLogin);
  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormMessage("");
    if (isCreateAccount) {
      if (mode === "hr") {
        setFormMessage("HR administrator accounts require an organization invite or existing admin approval. Switch to Employee to create an account.");
        return;
      }
      signUp.mutate({ name, email, password, employeeId, mode });
    } else {
      signIn.mutate({ identifier, password, mode });
    }
  };
  const isSubmitting = signIn.isPending || signUp.isPending;
  const mutationError = signIn.error?.message ?? signUp.error?.message ?? "";

  return (
    <main className="login-page">
      <div className="login-orbit login-orbit-one" />
      <div className="login-orbit login-orbit-two" />
      <section className="login-shell" aria-labelledby="login-title">
        <div className="login-brand-row"><div className="brand-mark login-brand-mark"><span /><span /><span /></div><div><strong>dayflow</strong><small>people, in sync.</small></div></div>
        <div className="login-copy"><span className="login-kicker"><Sparkles size={14} /> Calm people operations</span><h1 id="login-title">Make work feel <em>in sync.</em></h1><p>One thoughtful workspace for people, attendance, time-off, payroll, and the rhythm between them.</p></div>
        <div className="login-card">
          <div className="login-card-heading"><div><span className="section-kicker">{isCreateAccount ? "GET STARTED" : "WELCOME BACK"}</span><h2>{isCreateAccount ? "Create your workspace account" : "Sign in to your workspace"}</h2></div><div className="login-pulse"><span /><span /><span /></div></div>
          <p className="login-card-sub">{isCreateAccount ? "Set up your secure Dayflow access in a few steps." : "Choose how you work, then continue with your credentials."}</p>
          <div className="login-mode-tabs" role="tablist" aria-label="Login type"><button className={mode === "employee" ? "active" : ""} onClick={() => handleModeChange("employee")} role="tab" aria-selected={mode === "employee"}>Employee</button><button className={mode === "hr" ? "active" : ""} onClick={() => handleModeChange("hr")} role="tab" aria-selected={mode === "hr"}>HR administrator</button></div>
          <div className="workspace-picker-wrap"><span className="login-field-label">YOUR ORGANIZATION</span><button type="button" className="workspace-picker" onClick={() => setWorkspaceOpen((open) => !open)} aria-expanded={workspaceOpen}><span className="workspace-picker-avatar" style={{ background: selectedWorkspace.color }}>{selectedWorkspace.initials}</span><span><strong>{selectedWorkspace.name}</strong><small>{selectedWorkspace.detail}</small></span><ChevronDown size={15} /></button>{workspaceOpen && <div className="workspace-options">{workspaces.map((workspace) => <button type="button" key={workspace.name} onClick={() => { setSelectedWorkspace(workspace); setWorkspaceOpen(false); }}><span className="workspace-picker-avatar" style={{ background: workspace.color }}>{workspace.initials}</span><span><strong>{workspace.name}</strong><small>{workspace.detail}</small></span>{selectedWorkspace.name === workspace.name && <Check size={15} />}</button>)}</div>}</div>
          {authMessage && <div className="login-error" role="alert">{authMessage}</div>}
          {(mutationError || formMessage) && <div className={mutationError ? "login-error" : "login-success"} role="status">{mutationError || formMessage}</div>}
          <form onSubmit={handleSubmit} className="login-form">
            {isCreateAccount && <><label><span>FULL NAME</span><input value={name} onChange={(event) => setName(event.target.value)} placeholder="Your full name" required /></label><label><span>EMAIL ADDRESS</span><input type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@company.com" required /></label><label><span>EMPLOYEE ID</span><input value={employeeId} onChange={(event) => setEmployeeId(event.target.value)} placeholder="DF-2048" required /></label></>}
            {!isCreateAccount && <label><span>{mode === "hr" ? "WORK EMAIL OR ADMIN ID" : "EMAIL OR EMPLOYEE ID"}</span><input value={identifier} onChange={(event) => setIdentifier(event.target.value)} placeholder={mode === "hr" ? "hr@company.com" : "you@company.com or DF-2048"} autoComplete="username" required /></label>}
            <label><span>PASSWORD</span><input type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder={isCreateAccount ? "At least 8 characters" : "Enter your password"} minLength={isCreateAccount ? 8 : 1} autoComplete={isCreateAccount ? "new-password" : "current-password"} required /></label>
            <Button className="login-button" type="submit" disabled={loading || isSubmitting}><Building2 size={16} />{isSubmitting ? <><Loader2 size={15} className="animate-spin" /> Working…</> : isCreateAccount ? "Create account" : `Sign in as ${mode === "hr" ? "HR" : "Employee"}`}<ArrowRight size={16} /></Button>
          </form>
          <div className="login-switch"><span>{isCreateAccount ? "Already have an account?" : "New to Dayflow?"}</span><button type="button" onClick={() => { setIsCreateAccount((value) => !value); setFormMessage(""); }}> {isCreateAccount ? "Sign in" : "Create account"}</button></div>
          <div className="login-divider"><span>or</span></div>
          <button type="button" className="login-oauth-button" onClick={handleOAuth} disabled={loading}><ShieldCheck size={15} /> Continue with Google securely</button>
          <div className="login-trust"><ShieldCheck size={15} /><span>Your workspace stays private and secure.</span></div>
        </div>
        <div className="login-footer"><span>© 2026 Dayflow</span><span className="login-footer-dot" /><span>Powered for Northstar Labs</span></div>
      </section>
    </main>
  );
}
