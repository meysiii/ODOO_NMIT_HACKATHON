import { useEffect, useMemo, useRef, useState } from "react";
import {
  Activity,
  ArrowRight,
  Bell,
  Moon,
  Sun,
  BriefcaseBusiness,
  CalendarDays,
  Check,
  ChevronDown,
  Clock3,
  Command,
  FileText,
  Filter,
  HeartPulse,
  LayoutDashboard,
  Loader2,
  LogOut,
  MoreHorizontal,
  Palmtree,
  Search,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  UserRound,
  Users,
  WalletCards,
  X,
  Zap,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useTheme } from "@/contexts/ThemeContext";
import { trpc } from "@/lib/trpc";
import AdminOnboardingChecklist from "@/components/AdminOnboardingChecklist";
import { demoAttendance, demoLeaveRequests, demoWorkload, formatLastSynced, getDashboardConnectionMode, readDashboardCache, shouldAnnounceReconnect, writeDashboardCache } from "@shared/dayflow";

type Page = "overview" | "people" | "attendance" | "leave" | "payroll" | "pulse" | "profile";

const people = [
  { id: "DF-2048", name: "Aarav Mehta", role: "Product Designer", dept: "Design", status: "Present", hours: "7h 42m", initials: "AM", color: "#D5B9FF" },
  { id: "DF-2049", name: "HR Manager", role: "HR Manager", dept: "People", status: "Present", hours: "8h 06m", initials: "HR", color: "#BFE9D6" },
  { id: "DF-2050", name: "Kabir Rao", role: "Frontend Engineer", dept: "Engineering", status: "On leave", hours: "—", initials: "KR", color: "#FFD6A5" },
  { id: "DF-2051", name: "Diya Shah", role: "Product Manager", dept: "Product", status: "Present", hours: "7h 18m", initials: "DS", color: "#FFC4D6" },
  { id: "DF-2052", name: "Rohan Das", role: "Backend Engineer", dept: "Engineering", status: "Half day", hours: "4h 02m", initials: "RD", color: "#B9D9FF" },
];

const activity = [
  { icon: CalendarDays, title: "An employee submitted a leave request", meta: "Sick leave · 12–13 Aug", tone: "rose" },
  { icon: Clock3, title: "5 people checked in", meta: "Today · 09:12 average", tone: "mint" },
  { icon: FileText, title: "Payroll cycle is ready", meta: "July 2026 · 24 payslips", tone: "lavender" },
];

const nav = [
  { id: "overview" as Page, label: "Overview", icon: LayoutDashboard },
  { id: "people" as Page, label: "People", icon: Users },
  { id: "attendance" as Page, label: "Attendance", icon: Clock3 },
  { id: "leave" as Page, label: "Leave & time-off", icon: Palmtree, count: 3 },
  { id: "payroll" as Page, label: "Payroll", icon: WalletCards },
  { id: "pulse" as Page, label: "Workforce Pulse", icon: HeartPulse, accent: true },
];

function StatusPill({ status }: { status: string }) {
  const styles: Record<string, string> = {
    Present: "status-present",
    "On leave": "status-leave",
    "Half day": "status-half",
    Pending: "status-pending",
    Approved: "status-approved",
    Rejected: "status-rejected",
  };
  return <span className={`status-pill ${styles[status] ?? "status-neutral"}`}><span className="status-dot" />{status}</span>;
}

function Avatar({ initials, color, size = "md" }: { initials: string; color: string; size?: "sm" | "md" | "lg" }) {
  return <div className={`avatar avatar-${size}`} style={{ background: color }}>{initials}</div>;
}

export default function Home() {
  const [page, setPage] = useState<Page>("overview");
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showQuickAdd, setShowQuickAdd] = useState(false);
  const [showAdminChecklist, setShowAdminChecklist] = useState(() => { try { return !window.localStorage.getItem("dayflow-admin-onboarding-complete"); } catch { return false; } });
  const [checkedIn, setCheckedIn] = useState(false);
  const [leaveState, setLeaveState] = useState("Pending");
  const [query, setQuery] = useState("");
  const [period, setPeriod] = useState("This week");
  const [selectedPersonId, setSelectedPersonId] = useState("DF-2048");
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { theme, toggleTheme } = useTheme();
  const dashboardQuery = trpc.dashboard.data.useQuery(undefined, { enabled: isAuthenticated, retry: 2, retryDelay: (attempt) => Math.min(1000 * 2 ** attempt, 4000) });
  const notificationQuery = trpc.notifications.list.useQuery(undefined, { enabled: isAuthenticated, retry: 2, retryDelay: (attempt) => Math.min(1000 * 2 ** attempt, 4000) });
  const [isOnline, setIsOnline] = useState(() => typeof navigator === "undefined" ? true : navigator.onLine);
  const [cachedDashboard, setCachedDashboard] = useState<typeof dashboardQuery.data>();
  const [lastSyncedAt, setLastSyncedAt] = useState<number>();
  const [showReconnectSuccess, setShowReconnectSuccess] = useState(false);
  const liveDashboard = dashboardQuery.data ?? cachedDashboard;

  useEffect(() => {
    if (!authLoading && !isAuthenticated) setLocation("/login");
  }, [authLoading, isAuthenticated, setLocation]);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => { window.removeEventListener("online", handleOnline); window.removeEventListener("offline", handleOffline); };
  }, []);

  useEffect(() => {
    if (dashboardQuery.data) {
      setCachedDashboard(dashboardQuery.data);
      writeDashboardCache(window.localStorage, dashboardQuery.data);
      const syncedAt = Date.now();
      setLastSyncedAt(syncedAt);
      window.localStorage.setItem("dayflow-dashboard-last-synced", String(syncedAt));
    }
  }, [dashboardQuery.data]);

  useEffect(() => {
    if (!dashboardQuery.data) {
      setCachedDashboard(readDashboardCache<typeof dashboardQuery.data>(window.localStorage));
      const cachedTimestamp = window.localStorage.getItem("dayflow-dashboard-last-synced");
      if (cachedTimestamp) setLastSyncedAt(Number(cachedTimestamp));
    }
  }, []);

  const notificationUtils = trpc.useUtils();
  const markNotificationRead = trpc.notifications.markRead.useMutation({ onSuccess: () => notificationUtils.notifications.list.invalidate() });
  const markAllNotificationsRead = trpc.notifications.markAllRead.useMutation({ onSuccess: () => notificationUtils.notifications.list.invalidate() });

  const livePeople = useMemo(() => liveDashboard?.employees?.map((employee) => ({ id: employee.employeeId, name: employee.fullName, role: employee.jobTitle ?? "Team member", dept: employee.department ?? "People", status: "Present", hours: "—", initials: employee.fullName.split(" ").map((part) => part[0]).join("").slice(0, 2).toUpperCase(), color: "#D5B9FF" })) ?? [], [liveDashboard?.employees]);
  const peopleSource = livePeople.length > 0 ? livePeople : people;
  const filteredPeople = useMemo(() => peopleSource.filter((person) => `${person.name} ${person.role} ${person.dept}`.toLowerCase().includes(query.toLowerCase())), [query, peopleSource]);
  const isHR = user?.role === "admin";
  const liveMetrics = liveDashboard?.metrics;
  const unreadNotifications = notificationQuery.data?.filter((notification) => !notification.readAt).length ?? 0;
  const connectionMode = getDashboardConnectionMode({ isOnline, isFetching: dashboardQuery.isFetching && !dashboardQuery.isLoading, hasError: !!dashboardQuery.error, hasCache: !!cachedDashboard });
  const previousConnectionMode = useRef(connectionMode);
  useEffect(() => {
    if (shouldAnnounceReconnect(previousConnectionMode.current, connectionMode)) {
      toast.success("Live data restored", { description: "Dayflow is connected and your dashboard is up to date." });
      setShowReconnectSuccess(true);
      window.setTimeout(() => setShowReconnectSuccess(false), 1500);
    }
    previousConnectionMode.current = connectionMode;
  }, [connectionMode]);

  const go = (next: Page) => setPage(next);
  const completeCheckin = () => { setCheckedIn((value) => !value); toast.success(checkedIn ? "Check-out recorded" : "You are checked in", { description: checkedIn ? "Workday closed at 17:42" : "Your workday timer has started" }); };
  const decideLeave = (next: string) => { setLeaveState(next); toast.success(`Leave request ${next.toLowerCase()}`, { description: "The employee record updated immediately." }); };

  return (
    <div className={`app-shell ${showReconnectSuccess ? "reconnected-flash" : ""}`}>
      <aside className="sidebar">
        <div className="brand"><div className="brand-mark"><span /><span /><span /></div><div><strong>dayflow</strong><small>people, in sync.</small></div></div>
        <div className="workspace-switch"><div className="workspace-avatar">N</div><div><strong>Northstar Labs</strong><small>People workspace</small></div><ChevronDown size={15} /></div>
        <div className="sidebar-label">Workspace</div>
        <nav className="main-nav">{nav.map((item) => <button key={item.id} onClick={() => go(item.id)} className={`nav-item ${page === item.id ? "active" : ""} ${item.accent ? "pulse-nav" : ""}`}><item.icon size={18} strokeWidth={page === item.id ? 2.4 : 1.8} /><span>{item.label}</span>{item.count && <b>{item.count}</b>}{item.accent && <Sparkles size={13} className="nav-spark" />}</button>)}</nav>
        <div className="sidebar-label sidebar-label-bottom">Manage</div>
        <button className="nav-item" onClick={() => go("profile")}><UserRound size={18} /><span>My profile</span></button>
        <button className="nav-item" onClick={() => setShowAdminChecklist(true)}><Command size={18} /><span>Setup checklist</span></button>
        <div className="sidebar-footer"><div className="secure-note"><ShieldCheck size={16} /><span>Your workspace is private</span></div><div className="profile-chip"><Avatar initials={isHR ? "HR" : "AM"} color={isHR ? "#BFE9D6" : "#D5B9FF"} size="sm" /><div><strong>{isHR ? "HR Manager" : "Aarav Mehta"}</strong><small>{isHR ? "HR Manager" : "Product Designer"}</small></div><MoreHorizontal size={16} /></div></div>
      </aside>

      <main className="main-content">
        <header className="topbar"><div className="crumbs"><span>Northstar Labs</span><span>/</span><strong>{nav.find((item) => item.id === page)?.label ?? "My profile"}</strong></div><div className="top-actions"><div className="role-toggle" aria-label={`Signed in as ${isHR ? "HR Manager" : "Employee"}`}><span className={`role-dot ${isHR ? "hr-dot" : "employee-dot"}`} />{isHR ? "HR Manager" : "Employee"}</div><NotificationCenter notifications={notificationQuery.data ?? []} unreadCount={unreadNotifications} onRead={(id) => markNotificationRead.mutate({ id })} onReadAll={() => markAllNotificationsRead.mutate()} /><span className={`connection-indicator ${connectionMode}`} title={connectionMode === "offline" ? "Offline mode" : connectionMode === "reconnecting" ? "Reconnecting" : "Live connection"}><span />{connectionMode === "offline" ? "Offline" : connectionMode === "reconnecting" ? "Syncing" : "Live"}</span><button className="theme-toggle" onClick={toggleTheme} aria-label={`Switch to ${theme === "light" ? "dark" : "light"} mode`}>{theme === "light" ? <Moon size={16} /> : <Sun size={16} />}<span>{theme === "light" ? "Night" : "Day"}</span></button><Avatar initials={isHR ? "HR" : "AM"} color={isHR ? "#BFE9D6" : "#D5B9FF"} /></div></header>

        <div className="page-wrap">
          {connectionMode !== "live" && <div className={`data-alert ${connectionMode === "offline" ? "data-alert-offline" : ""}`}><Bell size={15} /><span>{dashboardQuery.isFetching ? "Trying to reconnect to Dayflow…" : cachedDashboard ? "Offline mode: showing your last cached dashboard snapshot." : "Live records could not be refreshed."}</span><button onClick={() => dashboardQuery.refetch()} disabled={dashboardQuery.isFetching}>{dashboardQuery.isFetching ? "Retrying…" : "Refresh"}</button></div>}
          {page === "overview" && <Overview isHR={isHR} checkedIn={checkedIn} completeCheckin={completeCheckin} go={go} setShowOnboarding={setShowOnboarding} setShowQuickAdd={setShowQuickAdd} metrics={liveMetrics} loading={dashboardQuery.isLoading && !liveDashboard} reconnecting={connectionMode === "reconnecting"} offline={connectionMode === "offline"} lastSyncedAt={lastSyncedAt} onRefresh={() => dashboardQuery.refetch()} />}
          {page === "people" && <PeopleView filteredPeople={filteredPeople} query={query} setQuery={setQuery} setShowQuickAdd={setShowQuickAdd} selectedPersonId={selectedPersonId} setSelectedPersonId={setSelectedPersonId} />}
          {page === "attendance" && <AttendanceView isHR={isHR} checkedIn={checkedIn} completeCheckin={completeCheckin} period={period} setPeriod={setPeriod} />}
          {page === "leave" && <LeaveView isHR={isHR} leaveState={leaveState} decideLeave={decideLeave} />}
          {page === "payroll" && <PayrollView isHR={isHR} />}
          {page === "pulse" && <PulseView />}
          {page === "profile" && <ProfileView isHR={isHR} />}
        </div>
      </main>

      {showAdminChecklist && isHR && <AdminOnboardingChecklist onClose={() => setShowAdminChecklist(false)} />}
      {showOnboarding && <Onboarding onClose={() => setShowOnboarding(false)} onDone={() => { setShowOnboarding(false); toast.success("Welcome to Dayflow", { description: "Your workspace is ready for the walkthrough." }); }} />}
      {showQuickAdd && <QuickAdd onClose={() => setShowQuickAdd(false)} />}
    </div>
  );
}

function useLiveDashboard() { const { isAuthenticated } = useAuth(); return trpc.dashboard.data.useQuery(undefined, { enabled: isAuthenticated, staleTime: 30000, retry: 2, retryDelay: (attempt) => Math.min(1000 * 2 ** attempt, 4000) }); }

function Overview({ isHR, checkedIn, completeCheckin, go, setShowOnboarding, setShowQuickAdd, metrics, loading, reconnecting, offline, lastSyncedAt, onRefresh }: { isHR: boolean; checkedIn: boolean; completeCheckin: () => void; go: (p: Page) => void; setShowOnboarding: (v: boolean) => void; setShowQuickAdd: (v: boolean) => void; loading: boolean; reconnecting: boolean; offline: boolean; lastSyncedAt?: number; onRefresh: () => void; metrics?: { peopleTotal: number; peopleAtWork: number; loggedMinutes: number; plannedMinutes: number; attendanceRate: number; pendingLeaveCount: number; attendanceRecordCount: number; leaveRequestCount: number; payrollReadiness: number; latestPayMonth: string | null; latestNetPay: number } }) {
  const hours = metrics ? `${Math.floor(metrics.loggedMinutes / 60)}h` : "—";
  const cards = isHR
    ? [{ label: "People at work", value: metrics ? `${metrics.peopleAtWork} / ${metrics.peopleTotal}` : "—", note: metrics ? `${metrics.attendanceRate}% attendance rate` : "Loading live records", icon: Users, tone: "lilac" }, { label: "Hours logged", value: hours, note: metrics && metrics.plannedMinutes ? `${Math.round((metrics.loggedMinutes / metrics.plannedMinutes) * 100)}% of planned time` : "Loading live records", icon: Clock3, tone: "mint" }, { label: "Time-off to review", value: metrics ? String(metrics.pendingLeaveCount).padStart(2, "0") : "—", note: "Pending leave requests", icon: Palmtree, tone: "peach" }, { label: "Payroll readiness", value: metrics ? `${metrics.payrollReadiness}%` : "—", note: metrics?.latestPayMonth ? `${metrics.latestPayMonth} cycle` : "Awaiting payroll records", icon: WalletCards, tone: "blue" }]
    : [{ label: "Today’s status", value: checkedIn ? "Working" : "Not started", note: checkedIn ? "Timer active" : "Check in to start your day", icon: Clock3, tone: "lilac" }, { label: "Attendance records", value: metrics ? String(metrics.attendanceRecordCount) : "—", note: `${metrics?.attendanceRate ?? 0}% present in scope`, icon: CalendarDays, tone: "mint" }, { label: "Time-off requests", value: metrics ? String(metrics.leaveRequestCount) : "—", note: "Live request history", icon: Palmtree, tone: "peach" }, { label: "Latest net pay", value: metrics?.latestNetPay ? `₹${metrics.latestNetPay.toLocaleString("en-IN")}` : "—", note: metrics?.latestPayMonth ? `${metrics.latestPayMonth} payroll` : "Awaiting payroll records", icon: WalletCards, tone: "blue" }];
  return <>
    <section className="hero-row"><div><div className="eyebrow"><span className="eyebrow-line" />{isHR ? "Tuesday, 18 August 2026" : "Tuesday, 18 August 2026"}</div><h1>{isHR ? "Good morning, Maya" : "Good morning, Aarav"}<span className="wave">✦</span></h1><p className="hero-sub">{isHR ? "Here’s the pulse of your people today." : "Your workday, in one calm view."}</p></div><div className="hero-actions"><Button variant="outline" className="quiet-button" onClick={() => setShowOnboarding(true)}><Sparkles size={16} /> Product tour</Button>{isHR ? <Button className="primary-button" onClick={() => setShowQuickAdd(true)}><Users size={16} /> Add employee</Button> : <Button className={`primary-button ${checkedIn ? "button-stop" : ""}`} onClick={completeCheckin}><Clock3 size={16} /> {checkedIn ? "Check out" : "Check in"}</Button>}</div></section>
    {loading ? <div className="data-status"><Loader2 size={14} className="animate-spin" /><span>Syncing live people, attendance, leave, and payroll records…</span></div> : reconnecting ? <div className="data-status reconnecting"><Loader2 size={14} className="animate-spin" /><span>Reconnecting to your live workspace…</span><button onClick={onRefresh}>Retry now</button></div> : offline ? <div className="data-status offline"><Bell size={14} /><span>Read-only offline mode · showing cached dashboard data{lastSyncedAt ? ` · Last synced ${formatLastSynced(lastSyncedAt)}` : ""}</span><button onClick={onRefresh}>Refresh</button></div> : metrics && metrics.peopleTotal === 0 ? <div className="data-status empty"><Users size={14} /><span>Your live workspace is ready. Add an employee or connect records to see the rhythm here.</span></div> : null}
    <section className="summary-grid">{cards.map((item) => <Card key={item.label} className="summary-card"><CardContent><div className={`metric-icon ${item.tone}`}><item.icon size={18} /></div><div className="metric-label">{item.label}</div><div className="metric-value">{item.value}</div><div className="metric-note"><TrendingUp size={13} />{item.note}</div></CardContent></Card>)}</section>
    <section className="dashboard-grid"><Card className="card-span-2 activity-card"><CardHeader><div><div className="section-kicker">ACTIVITY STREAM</div><CardTitle>What’s moving today</CardTitle></div><Button variant="ghost" className="text-button" onClick={() => go(isHR ? "people" : "attendance")}>View {isHR ? "directory" : "attendance"}<ArrowRight size={15} /></Button></CardHeader><CardContent><div className="activity-list">{activity.map((item) => <div className="activity-row" key={item.title}><div className={`activity-icon ${item.tone}`}><item.icon size={17} /></div><div className="activity-copy"><strong>{item.title}</strong><span>{item.meta}</span></div><span className="activity-time">09:{item.tone === "rose" ? "12" : item.tone === "mint" ? "24" : "41"}</span></div>)}</div></CardContent></Card><PulseMini onOpen={() => go("pulse")} /></section>
    <section className="lower-grid"><AttendanceWeek isHR={isHR} /><Card className="quick-card"><CardHeader><div><div className="section-kicker">QUICK ACTIONS</div><CardTitle>Make it flow</CardTitle></div><Zap size={17} className="gold-icon" /></CardHeader><CardContent><button onClick={() => isHR ? setShowQuickAdd(true) : go("leave")} className="quick-action"><span className="quick-action-icon"><Users size={17} /></span><span><strong>{isHR ? "Add a new person" : "Request time off"}</strong><small>{isHR ? "Create a profile in under a minute" : "Plan ahead, keep your team in sync"}</small></span><ArrowRight size={16} /></button><button onClick={() => go("attendance")} className="quick-action"><span className="quick-action-icon"><CalendarDays size={17} /></span><span><strong>Review this week</strong><small>See the shape of your workdays</small></span><ArrowRight size={16} /></button></CardContent></Card></section>
  </>;
}

function PulseMini({ onOpen }: { onOpen: () => void }) { const pendingCount = demoLeaveRequests.filter((request) => request.status === "pending").length; const plannedMinutes = demoWorkload.reduce((sum, record) => sum + record.plannedMinutes, 0); const loggedMinutes = demoWorkload.reduce((sum, record) => sum + record.loggedMinutes, 0); const plannedRate = Math.round((loggedMinutes / plannedMinutes) * 100); return <Card className="pulse-mini"><CardContent><div className="pulse-top"><div className="pulse-orb"><HeartPulse size={21} /></div><Badge className="soft-badge">TRANSPARENT SIGNAL</Badge></div><h3>Team energy is steady</h3><p>Attendance is strong. One small action could make tomorrow smoother.</p><div className="pulse-evidence"><span><b>{pendingCount}</b> pending time-offs</span><span><b>{plannedRate}%</b> planned hours</span></div><button onClick={onOpen} className="pulse-link">See the evidence <ArrowRight size={14} /></button></CardContent></Card> }

function AttendanceWeek({ isHR }: { isHR: boolean }) { const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]; const { data } = useLiveDashboard(); const vals = days.map((_, index) => Number(((data?.attendance?.[index]?.workMinutes ?? 0) / 60).toFixed(1))); return <Card className="card-span-2"><CardHeader><div><div className="section-kicker">ATTENDANCE RHYTHM</div><CardTitle>{isHR ? "Team hours this week" : "Your week at a glance"}</CardTitle></div><Button variant="ghost" className="text-button">This week <ChevronDown size={14} /></Button></CardHeader><CardContent><div className="week-chart">{days.map((day, index) => <div className="day-column" key={day}><div className="bar-track"><div className={`bar-fill ${index === 1 ? "today" : ""}`} style={{ height: `${vals[index] * 9}%` }} /></div><span className={index === 1 ? "today-label" : ""}>{day}</span><small>{vals[index] ? `${vals[index]}h` : "—"}</small></div>)}</div></CardContent></Card> }

function PeopleView({ filteredPeople, query, setQuery, setShowQuickAdd, selectedPersonId, setSelectedPersonId }: { filteredPeople: typeof people; query: string; setQuery: (v: string) => void; setShowQuickAdd: (v: boolean) => void; selectedPersonId: string; setSelectedPersonId: (v: string) => void }) { const { data } = useLiveDashboard(); const selected = filteredPeople.find((person) => person.id === selectedPersonId) ?? filteredPeople[0] ?? people[0]; const selectedEmployee = data?.employees?.find((employee) => employee.employeeId === selected.id); const selectedPayroll = data?.payroll?.find((row) => row.employeeId === selectedEmployee?.id); const selectedLeaveDays = data?.leaveRequests?.filter((request) => request.employeeId === selectedEmployee?.id && request.status === "approved").reduce((sum, request) => sum + Number(request.days), 0) ?? 0; return <><PageIntro eyebrow="DIRECTORY" title="People, not paperwork." subtitle="A clear view of everyone who makes Northstar move." action={<Button className="primary-button" onClick={() => setShowQuickAdd(true)}><Users size={16} /> Add employee</Button>} /><Card className="table-card"><CardHeader><div className="search-wrap"><Search size={17} /><Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search by name, role or team…" /></div><Button variant="outline" className="filter-button"><Filter size={15} /> Filters</Button></CardHeader><CardContent><div className="table-wrap"><table><thead><tr><th>Person</th><th>Team</th><th>Today</th><th>Hours</th><th>Employee ID</th><th /></tr></thead><tbody>{filteredPeople.length === 0 ? <tr><td colSpan={6}><div className="empty-state"><Search size={18} /><strong>No people match that search</strong><span>Try a name, team, or employee ID.</span></div></td></tr> : filteredPeople.map((person) => <tr key={person.id}><td><div className="person-cell"><Avatar initials={person.initials} color={person.color} /><div><strong>{person.name}</strong><small>{person.role}</small></div></div></td><td><span className="team-tag">{person.dept}</span></td><td><StatusPill status={person.status} /></td><td className="hours-cell">{person.hours}</td><td className="muted-cell">{person.id}</td><td><button className="row-more" onClick={() => { setSelectedPersonId(person.id); toast.success(`${person.name} selected`, { description: "The HR context panel is now focused on this employee." }); }}><MoreHorizontal size={17} /></button></td></tr>)}</tbody></table></div></CardContent></Card><Card className="selected-person-card"><CardContent><div className="selected-person-label">SELECTED EMPLOYEE CONTEXT</div><div className="selected-person-main"><Avatar initials={selected.initials} color={selected.color} /><div><strong>{selected.name}</strong><span>{selected.role} · {selected.dept} · {selected.id}</span></div><StatusPill status={selected.status} /></div><div className="selected-person-metrics"><span><b>{selected.hours}</b> today</span><span><b>{selectedLeaveDays}d</b> approved leave</span><span><b>{selectedPayroll ? `₹${(Number(selectedPayroll.basic) + Number(selectedPayroll.hra) + Number(selectedPayroll.benefits) - Number(selectedPayroll.deductions)).toLocaleString("en-IN")}` : "—"}</b> net pay</span></div></CardContent></Card></> }

function AttendanceView({ isHR, checkedIn, completeCheckin, period, setPeriod }: { isHR: boolean; checkedIn: boolean; completeCheckin: () => void; period: string; setPeriod: (v: string) => void }) { const { data } = useLiveDashboard(); const liveAttendance = data?.attendance ?? []; const selectedDate = liveAttendance[0]?.workDate ? new Date(liveAttendance[0].workDate) : new Date(); const selectedIndex = selectedDate.getDate() - 1; const periodLabel = liveAttendance[0]?.workDate ? selectedDate.toLocaleString(undefined, { month: "long", year: "numeric" }) : "Live attendance"; const weekLabel = liveAttendance[0]?.workDate ? `Week ${Math.ceil(selectedDate.getDate() / 7)}` : "No records yet"; const liveDays = new Set(liveAttendance.map((row) => new Date(row.workDate).getDate() - 1)); const liveMinutes = liveAttendance.reduce((sum, row) => sum + (row.workMinutes ?? 0), 0); return <><PageIntro eyebrow="ATTENDANCE" title={isHR ? "The day, in motion." : "Your attendance, simplified."} subtitle={isHR ? "Real-time visibility without the spreadsheet chase." : "A calm record of your workdays and hours."} action={!isHR ? <Button className="primary-button" onClick={completeCheckin}><Clock3 size={16} />{checkedIn ? "Check out" : "Check in"}</Button> : <Button variant="outline" className="filter-button"><Filter size={15} /> Export report</Button>} /><div className="attendance-layout"><Card className="calendar-card"><CardHeader><div><div className="section-kicker">{periodLabel}</div><CardTitle>{weekLabel}</CardTitle></div><div className="month-nav"><button>‹</button><button>›</button></div></CardHeader><CardContent><div className="calendar-head">{["M", "T", "W", "T", "F", "S", "S"].map((d, i) => <span key={`${d}-${i}`}>{d}</span>)}</div><div className="calendar-grid">{Array.from({ length: 31 }, (_, i) => <div className={`calendar-day ${i === selectedIndex ? "selected" : ""} ${liveDays.has(i) ? "has-status" : ""}`} key={i}>{i + 1}{liveDays.has(i) && <i />}</div>)}</div><div className="calendar-legend"><span><i className="legend-present" />Present</span><span><i className="legend-leave" />Leave</span><span><i className="legend-half" />Half-day</span></div></CardContent></Card><div className="attendance-side"><Card className="hours-focus"><CardContent><div className="section-kicker">{isHR ? "TEAM TOTAL" : "TODAY"}</div><div className="big-hours">{isHR ? `${Math.floor(liveMinutes / 60)}h ${liveMinutes % 60}m` : checkedIn ? "07h 42m" : "00h 00m"}</div><p>{isHR ? `${data?.metrics.attendanceRate ?? 0}% of scoped attendance records present` : checkedIn ? "You’re on a healthy pace" : "Your timer starts when you check in"}</p><Progress value={isHR ? (data?.metrics.attendanceRate ?? 0) : checkedIn ? 82 : 0} /><div className="hours-meta"><span>Start <b>{liveAttendance[0]?.checkIn ? new Date(liveAttendance[0].checkIn).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "—"}</b></span><span>Target <b>{liveAttendance.length ? `${liveAttendance.length * 8}h` : "—"}</b></span></div></CardContent></Card><Card className="attendance-list"><CardHeader><CardTitle>Recent records</CardTitle><button className="period-select" onClick={() => setPeriod(period === "This week" ? "This month" : "This week")}>{period}<ChevronDown size={14} /></button></CardHeader><CardContent>{!liveAttendance.length && <div className="empty-state"><Clock3 size={18} /><strong>No attendance records yet</strong><span>Live check-ins will appear here.</span></div>}{(liveAttendance.length ? liveAttendance.slice(0, 4).map((record) => ({ id: String(record.id), name: `Employee ${record.employeeId}`, dept: record.status, hours: `${Math.floor((record.workMinutes ?? 0) / 60)}h ${(record.workMinutes ?? 0) % 60}m`, initials: "DF", color: "#D5B9FF" })) : []).map((person) => <div className="mini-record" key={person.id}><Avatar initials={person.initials} color={person.color} size="sm" /><div><strong>{person.name}</strong><small>{person.dept}</small></div><span>{person.hours}</span></div>)}</CardContent></Card></div></div></> }

function LeaveView({ isHR, leaveState, decideLeave }: { isHR: boolean; leaveState: string; decideLeave: (v: string) => void }) { const { data } = useLiveDashboard(); const liveLeave = data?.leaveRequests ?? []; const pendingLive = liveLeave.filter((request) => request.status === "pending").length; const paidDays = liveLeave.filter((request) => request.type === "paid" && request.status === "approved").reduce((sum, request) => sum + Number(request.days), 0); const sickDays = liveLeave.filter((request) => request.type === "sick" && request.status === "approved").reduce((sum, request) => sum + Number(request.days), 0); const unpaidDays = liveLeave.filter((request) => request.type === "unpaid" && request.status === "approved").reduce((sum, request) => sum + Number(request.days), 0); return <><PageIntro eyebrow="LEAVE & TIME-OFF" title={isHR ? "Keep plans human." : "Time off, without the back-and-forth."} subtitle={isHR ? "Make fair, informed decisions with the full context in view." : "Request time away and keep your team aligned."} action={!isHR ? <Button className="primary-button" onClick={() => toast.success("Leave request started", { description: "Choose dates and a leave type to continue." })}><Palmtree size={16} /> Request leave</Button> : <Button variant="outline" className="filter-button"><Filter size={15} /> Filter requests</Button>} /><div className="leave-layout"><Card className="balance-card"><CardHeader><div><div className="section-kicker">YOUR BALANCE</div><CardTitle>Time-off wallet</CardTitle></div><Palmtree className="gold-icon" size={20} /></CardHeader><CardContent><div className="balance-total">{(paidDays + sickDays).toFixed(1)} <span>approved days</span></div><div className="balance-line"><span>Paid leave</span><b>{paidDays}d</b><Progress value={Math.min(100, paidDays * 10)} /></div><div className="balance-line"><span>Sick leave</span><b>{sickDays}d</b><Progress value={Math.min(100, sickDays * 10)} /></div><div className="balance-line"><span>Unpaid leave</span><b>{unpaidDays}d</b><Progress value={Math.min(100, unpaidDays * 10)} /></div><p className="balance-footnote">Balances refresh immediately when a request is approved.</p></CardContent></Card><Card className="requests-card"><CardHeader><div><div className="section-kicker">{isHR ? "INBOX" : "REQUEST HISTORY"}</div><CardTitle>{isHR ? "Needs your attention" : "Your requests"}</CardTitle></div><Badge className="count-badge">{isHR ? `${pendingLive} pending` : `${liveLeave.length} requests`}</Badge></CardHeader><CardContent><div className="request-list">{liveLeave.map((request) => ({ name: `Employee ${request.employeeId}`, initials: "DF", type: request.type, dates: `${String(request.startDate)} · ${request.days} day(s)`, status: request.status === "approved" ? "Approved" : request.status === "rejected" ? "Rejected" : "Pending", color: "#D5B9FF" })).map((request) => <div className="request-row" key={`${request.name}-${request.type}`}><Avatar initials={request.initials} color={request.color} size="sm" /><div className="request-copy"><strong>{isHR ? request.name : request.type}</strong><span>{request.dates}</span></div><StatusPill status={request.status} />{isHR && request.status === "Pending" && <div className="request-actions"><button onClick={() => decideLeave("Approved")} className="approve-button"><Check size={14} /></button><button onClick={() => decideLeave("Rejected")} className="reject-button"><X size={14} /></button></div>}</div>)}</div></CardContent></Card></div><Card className="explain-card"><CardContent><div className="explain-icon"><ShieldCheck size={18} /></div><div><strong>Decisions stay explainable.</strong><p>Every status change keeps the request, dates, leave type, and HR comment together. No hidden automation decides for your people.</p></div><button onClick={() => toast.info("Audit trail opened", { description: "Every request change is recorded with actor and timestamp." })}>View audit trail <ArrowRight size={14} /></button></CardContent></Card></> }

function PayrollView({ isHR }: { isHR: boolean }) { const { data } = useLiveDashboard(); const livePayroll = data?.payroll ?? []; const liveMetrics = data?.metrics; const latest = livePayroll[0]; const basic = latest ? Number(latest.basic) : 0; const allowances = latest ? Number(latest.hra) + Number(latest.benefits) : 0; const withheld = latest ? Number(latest.deductions) : 0; return <><PageIntro eyebrow="PAYROLL" title="Clarity at payday." subtitle={isHR ? "A clean control room for salary structures and payroll readiness." : "Your salary structure, clearly explained."} action={isHR ? <Button className="primary-button" onClick={() => toast.success("Payroll cycle marked ready")}>Mark cycle ready <Check size={16} /></Button> : <Button variant="outline" className="filter-button"><FileText size={15} /> Download payslip</Button>} /><div className="payroll-grid"><Card className="net-card"><CardContent><div className="section-kicker">{isHR ? "JULY 2026 · TEAM NET PAY" : "JULY 2026 · NET PAY"}</div><div className="net-value">{liveMetrics?.latestNetPay ? `₹${liveMetrics.latestNetPay.toLocaleString("en-IN")}` : "—"}</div><div className="net-note"><TrendingUp size={14} /> {liveMetrics?.latestPayMonth ? `${livePayroll.length} payroll record(s) · ${liveMetrics.payrollReadiness}% ready` : "No payroll records in scope yet"}</div><Separator /><div className="pay-meta"><span>Basic <b>₹{basic.toLocaleString("en-IN")}</b></span><span>Allowances <b>₹{allowances.toLocaleString("en-IN")}</b></span><span>Withheld <b>₹{withheld.toLocaleString("en-IN")}</b></span></div></CardContent></Card><Card className="components-card"><CardHeader><div><div className="section-kicker">SALARY STRUCTURE</div><CardTitle>{isHR ? "Components & controls" : "How your pay adds up"}</CardTitle></div><WalletCards size={19} className="blue-icon" /></CardHeader><CardContent>{[{ label: "Basic salary", value: latest ? `₹${basic.toLocaleString("en-IN")}` : "—", color: "#8C7CF5" }, { label: "House rent allowance", value: latest ? `₹${Number(latest.hra).toLocaleString("en-IN")}` : "—", color: "#5BC8A5" }, { label: "Flexible benefits", value: latest ? `₹${Number(latest.benefits).toLocaleString("en-IN")}` : "—", color: "#F3B76B" }].map((item) => <div className="component-row" key={item.label}><span className="component-swatch" style={{ background: item.color }} /><span>{item.label}</span><b>{item.value}</b>{isHR && <button onClick={() => toast.info("Component editor opened")}>Edit</button>}</div>)}</CardContent></Card></div><div className="payroll-note"><ShieldCheck size={16} /><span>Payroll is permissioned by role. Employees can view their own information; only HR can edit salary components.</span></div></> }

function PulseView() { const { data } = useLiveDashboard(); const liveAttendance = data?.attendance ?? []; const liveLeave = data?.leaveRequests ?? []; const presentCount = liveAttendance.length ? liveAttendance.filter((record) => record.status === "present").length : 0; const onLeaveCount = liveAttendance.length ? liveAttendance.filter((record) => record.status === "leave").length : 0; const halfDayCount = liveAttendance.length ? liveAttendance.filter((record) => record.status === "half-day").length : 0; const pendingCount = liveLeave.filter((request) => request.status === "pending").length; const plannedMinutes = data?.metrics.plannedMinutes ?? 0; const loggedMinutes = data?.metrics.loggedMinutes ?? 0; const plannedHours = Math.round(loggedMinutes / 60); const attendanceRate = data?.metrics.attendanceRate ?? 0; const plannedRate = plannedMinutes ? Math.round((loggedMinutes / plannedMinutes) * 100) : 0; return <><PageIntro eyebrow="WORKFORCE PULSE" title="Signals, not scores." subtitle="Transparent operational cues that help HR act earlier—without profiling people." action={<Button variant="outline" className="filter-button"><ShieldCheck size={15} /> Privacy principles</Button>} /><div className="pulse-hero"><div className="pulse-hero-art"><div className="pulse-ring ring-one" /><div className="pulse-ring ring-two" /><div className="pulse-ring ring-three" /><HeartPulse size={42} /></div><div><Badge className="soft-badge">PRIVACY-CONSCIOUS BY DESIGN</Badge><h2>Team energy is steady, with one visible watchpoint.</h2><p>Pulse does not rank people or infer health, mood, or intent. It only surfaces patterns already present in operational records, with the evidence beside the cue.</p></div></div><div className="pulse-grid"><Card className="signal-card signal-good"><CardContent><div className="signal-head"><span className="signal-icon"><Check size={17} /></span><Badge className="signal-badge good">STEADY</Badge></div><h3>Attendance rhythm is healthy</h3><p>{presentCount} of {liveAttendance.length} visible people are present today, and the team has logged {plannedRate}% of planned hours.</p><div className="evidence-label">EVIDENCE</div><div className="evidence-row"><span>Present today</span><b>{attendanceRate}%</b></div><Progress value={attendanceRate} /></CardContent></Card><Card className="signal-card signal-watch"><CardContent><div className="signal-head"><span className="signal-icon"><Bell size={17} /></span><Badge className="signal-badge watch">WATCHPOINT</Badge></div><h3>{pendingCount} requests need a human decision</h3><p>{onLeaveCount} leave record and {pendingCount} pending time-offs are visible in the operational inbox. Reviewing them today will reduce planning friction.</p><div className="evidence-label">RECOMMENDED ACTION</div><button className="signal-action" onClick={() => toast.info("Opening leave inbox", { description: "Review requests in context and add a comment." })}>Review leave inbox <ArrowRight size={14} /></button></CardContent></Card><Card className="signal-card signal-neutral"><CardContent><div className="signal-head"><span className="signal-icon"><Activity size={17} /></span><Badge className="signal-badge neutral">CONTEXT</Badge></div><h3>Focus the next 1:1 on capacity</h3><p>{onLeaveCount} approved leave record and {halfDayCount} half-day record are visible in the current team context. The current workload context is {plannedHours} logged hours at {plannedRate}% of plan. No action is automated.</p><div className="evidence-label">VISIBLE RECORDS</div><div className="mini-tags"><span>Leave records</span><span>Attendance</span><span>Team hours</span></div></CardContent></Card></div><div className="pulse-principles"><div><ShieldCheck size={17} /><strong>Private by default</strong><span>Aggregate signals only</span></div><div><FileText size={17} /><strong>Evidence beside every cue</strong><span>Traceable to a record</span></div><div><UserRound size={17} /><strong>Human decision stays central</strong><span>Never auto-labels people</span></div></div></> }

function ProfileView({ isHR }: { isHR: boolean }) { return <><PageIntro eyebrow="PROFILE" title={isHR ? "Your people, with context." : "A profile that stays yours."} subtitle={isHR ? "Manage the details that help your team do their best work." : "Keep your personal and job details current."} action={<Button className="primary-button" onClick={() => toast.success("Profile saved", { description: "Your changes are now visible to the right people." })}>Save changes <Check size={16} /></Button>} /><div className="profile-layout"><Card className="profile-card"><CardContent><div className="profile-cover" /><div className="profile-main"><Avatar initials={isHR ? "HR" : "AM"} color={isHR ? "#BFE9D6" : "#D5B9FF"} size="lg" /><div><h2>{isHR ? "HR Manager" : "Aarav Mehta"}</h2><p>{isHR ? "HR Manager · People" : "Product Designer · Design"}</p><Badge className="soft-badge">{isHR ? "HR MANAGER" : "EMPLOYEE"}</Badge></div></div><div className="form-grid"><label>Full name<input defaultValue={isHR ? "HR Manager" : "Aarav Mehta"} /></label><label>Employee ID<input defaultValue={isHR ? "DF-2049" : "DF-2048"} disabled /></label><label>Work email<input defaultValue={isHR ? "hr.manager@northstar.dev" : "aarav@northstar.dev"} /></label><label>Phone<input defaultValue="+91 98765 43210" /></label><label className="span-two">Address<input defaultValue="Indiranagar, Bengaluru" /></label></div></CardContent></Card><Card className="details-card"><CardHeader><div><div className="section-kicker">JOB DETAILS</div><CardTitle>Work at a glance</CardTitle></div><BriefcaseBusiness size={19} className="blue-icon" /></CardHeader><CardContent><div className="detail-row"><span>Department</span><b>{isHR ? "People" : "Design"}</b></div><div className="detail-row"><span>Manager</span><b>Priya Nair</b></div><div className="detail-row"><span>Joined</span><b>14 February 2024</b></div><div className="detail-row"><span>Work mode</span><b>Hybrid</b></div><Separator /><div className="section-kicker salary-kicker">SALARY STRUCTURE</div><div className="detail-row"><span>Annual CTC</span><b>₹{isHR ? "18,00,000" : "15,00,000"}</b></div><div className="detail-row"><span>Pay cycle</span><b>Monthly</b></div></CardContent></Card></div></> }

function PageIntro({ eyebrow, title, subtitle, action }: { eyebrow: string; title: string; subtitle: string; action?: React.ReactNode }) { return <section className="page-intro"><div><div className="eyebrow"><span className="eyebrow-line" />{eyebrow}</div><h1>{title}</h1><p className="hero-sub">{subtitle}</p></div>{action && <div className="hero-actions">{action}</div>}</section> }

function Onboarding({ onClose, onDone }: { onClose: () => void; onDone: () => void }) { const [step, setStep] = useState(1); const [accessRole, setAccessRole] = useState("Employee"); const [employeeId, setEmployeeId] = useState(""); const [email, setEmail] = useState(""); const [password, setPassword] = useState(""); const accessReady = employeeId.trim().length >= 4 && email.includes("@") && password.length >= 8; return <div className="modal-backdrop"><div className="modal onboarding-modal"><button className="modal-close" onClick={onClose}><X size={18} /></button>{step === 1 ? <><div className="modal-kicker">WELCOME TO DAYFLOW</div><div className="onboarding-orb"><Sparkles size={28} /></div><h2>Make work feel more human.</h2><p>Dayflow brings people data, daily operations, and thoughtful decisions into one calm workspace.</p><div className="access-form"><div className="access-role-tabs"><button className={accessRole === "Employee" ? "selected" : ""} onClick={() => setAccessRole("Employee")}>Employee</button><button className={accessRole === "HR" ? "selected" : ""} onClick={() => setAccessRole("HR")}>Admin / HR</button></div><label>Employee ID<input value={employeeId} onChange={(event) => setEmployeeId(event.target.value)} placeholder="e.g. DF-2048" /></label><label>Work email<input type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@company.com" /></label><label>Password<input type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="8+ characters" /></label><div className="verification-ready"><ShieldCheck size={14} /> Email verification-ready · role: {accessRole}</div></div><div className="tour-points"><span><Check size={14} />One source of truth for every workday</span><span><Check size={14} />Self-service for employees, context for HR</span><span><Check size={14} />Signals with evidence—not black-box scores</span></div><Button className="primary-button full-button" disabled={!accessReady} onClick={() => setStep(2)}>Take the 60-second tour <ArrowRight size={16} /></Button></> : <><div className="modal-kicker">THE DAYFLOW PROMISE</div><div className="tour-visual"><div><Clock3 size={19} /><span>Attend</span></div><ArrowRight size={15} /><div><Palmtree size={19} /><span>Plan</span></div><ArrowRight size={15} /><div><HeartPulse size={19} /><span>Act early</span></div></div><h2>Every decision stays explainable.</h2><p>From check-in to payroll, each action has a clear owner, a visible record, and an immediate outcome for the people it affects.</p><Button className="primary-button full-button" onClick={onDone}>Enter my workspace <Check size={16} /></Button></>}</div></div> }

function QuickAdd({ onClose }: { onClose: () => void }) { return <div className="modal-backdrop"><div className="modal quick-modal"><button className="modal-close" onClick={onClose}><X size={18} /></button><div className="modal-kicker">NEW PERSON</div><h2>Bring someone into the flow.</h2><p>Create a profile now. You can complete the rest with them later.</p><div className="form-grid quick-form"><label>Full name<input placeholder="e.g. Anika Rao" /></label><label>Employee ID<input placeholder="e.g. DF-2053" /></label><label>Work email<input placeholder="name@company.com" /></label><label>Department<select defaultValue="Engineering"><option>Engineering</option><option>Design</option><option>People</option><option>Product</option></select></label></div><div className="modal-actions"><Button variant="outline" className="quiet-button" onClick={onClose}>Cancel</Button><Button className="primary-button" onClick={() => { onClose(); toast.success("Invite ready", { description: "A secure email verification link is ready to send." }); }}>Create profile <ArrowRight size={16} /></Button></div></div></div> }


type PortalNotification = { id: number; title: string; body: string; kind: string; readAt: Date | null; createdAt: Date };

function NotificationCenter({ notifications, unreadCount, onRead, onReadAll }: { notifications: PortalNotification[]; unreadCount: number; onRead: (id: number) => void; onReadAll: () => void }) {
  const [open, setOpen] = useState(false);
  return <div className="notification-center">
    <button className="icon-button notification-trigger" onClick={() => setOpen((value) => !value)} aria-label={`${unreadCount} unread notifications`}><Bell size={18} />{unreadCount > 0 && <b>{unreadCount > 9 ? "9+" : unreadCount}</b>}</button>
    {open && <div className="notification-popover">
      <div className="notification-head"><div><span className="section-kicker">INBOX</span><strong>Notifications</strong></div>{unreadCount > 0 && <button onClick={onReadAll}>Mark all read</button>}</div>
      <div className="notification-list">{notifications.length === 0 ? <div className="notification-empty"><Bell size={17} /><strong>You’re all caught up</strong><span>New updates will appear here.</span></div> : notifications.map((notification) => <button className={`notification-item ${notification.readAt ? "read" : "unread"}`} key={notification.id} onClick={() => onRead(notification.id)}><span className={`notification-kind ${notification.kind}`} /><span className="notification-copy"><strong>{notification.title}</strong><span>{notification.body}</span><small>{new Date(notification.createdAt).toLocaleString([], { dateStyle: "medium", timeStyle: "short" })}</small></span>{!notification.readAt && <i />}</button>)}</div>
    </div>}
  </div>;
}
