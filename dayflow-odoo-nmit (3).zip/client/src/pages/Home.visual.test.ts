import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const homeSource = readFileSync(resolve(process.cwd(), "client/src/pages/Home.tsx"), "utf8");
const stylesSource = readFileSync(resolve(process.cwd(), "client/src/index.css"), "utf8");

describe("Dayflow portal visual contract", () => {
  it("keeps the primary portal navigation and role interactions present", () => {
    expect(homeSource).toContain('const [role, setRole] = useState<Role>("hr")');
    expect(homeSource).toContain('setRole(isHR ? "employee" : "hr")');
    expect(homeSource).toContain('setShowQuickAdd(true)');
    expect(homeSource).toContain('People, not paperwork.');
  });

  it("includes the signature rhythm effects and reduced-motion safeguard", () => {
    expect(stylesSource).toContain("body::before");
    expect(stylesSource).toContain("activity-list::before");
    expect(stylesSource).toContain("@keyframes dayflow-rise");
    expect(stylesSource).toContain("@media (prefers-reduced-motion: reduce)");
  });
});
