import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Login from "./pages/Login";
import { useAuth } from "@/_core/hooks/useAuth";

function LoginPage() { return <Login />; }
function HrLoginPage() { return <Login defaultMode="hr" />; }
function EmployeeLoginPage() { return <Login defaultMode="employee" />; }

function HomeGate() {
  const { isAuthenticated, loading } = useAuth();
  if (loading || !isAuthenticated) return <Login />;
  return <Home />;
}

function Router() {
  return (
    <Switch>
      <Route path="/login/hr" component={HrLoginPage} />
      <Route path="/login/employee" component={EmployeeLoginPage} />
      <Route path="/login" component={LoginPage} />
      <Route path="/" component={HomeGate} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light" switchable>
        <TooltipProvider>
          <Toaster position="top-right" />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
