export type LeaveStatus = "pending" | "approved" | "rejected";

export const demoAttendance = [
  { employeeId: "DF-2048", status: "present" as const, workMinutes: 462 },
  { employeeId: "DF-2049", status: "present" as const, workMinutes: 486 },
  { employeeId: "DF-2050", status: "leave" as const, workMinutes: 0 },
  { employeeId: "DF-2051", status: "present" as const, workMinutes: 438 },
  { employeeId: "DF-2052", status: "half-day" as const, workMinutes: 242 },
];

export const demoLeaveRequests = [
  { employeeId: "DF-2049", type: "sick" as const, startDate: "2026-08-12", endDate: "2026-08-13", status: "pending" as const },
  { employeeId: "DF-2048", type: "paid" as const, startDate: "2026-08-28", endDate: "2026-08-30", status: "pending" as const },
  { employeeId: "DF-2051", type: "paid" as const, startDate: "2026-09-05", endDate: "2026-09-05", status: "approved" as const },
];

export const demoWorkload = [
  { employeeId: "DF-2048", plannedMinutes: 480, loggedMinutes: 462 },
  { employeeId: "DF-2049", plannedMinutes: 480, loggedMinutes: 486 },
  { employeeId: "DF-2050", plannedMinutes: 480, loggedMinutes: 0 },
  { employeeId: "DF-2051", plannedMinutes: 480, loggedMinutes: 438 },
  { employeeId: "DF-2052", plannedMinutes: 480, loggedMinutes: 242 },
];

export function calculateWorkMinutes(checkIn: Date, checkOut: Date): number {
  const minutes = Math.floor((checkOut.getTime() - checkIn.getTime()) / 60000);
  return Math.max(0, minutes);
}

export function calculateLeaveDays(start: string, end: string): number {
  const from = new Date(`${start}T00:00:00Z`).getTime();
  const to = new Date(`${end}T00:00:00Z`).getTime();
  if (Number.isNaN(from) || Number.isNaN(to) || to < from) return 0;
  return Math.floor((to - from) / 86400000) + 1;
}

export function hasLeaveOverlap(candidateStart: string, candidateEnd: string, existing: Array<{ startDate: string; endDate: string; status: LeaveStatus }>): boolean {
  const start = new Date(`${candidateStart}T00:00:00Z`).getTime();
  const end = new Date(`${candidateEnd}T00:00:00Z`).getTime();
  return existing.some((item) => {
    if (item.status === "rejected") return false;
    const existingStart = new Date(`${item.startDate}T00:00:00Z`).getTime();
    const existingEnd = new Date(`${item.endDate}T00:00:00Z`).getTime();
    return start <= existingEnd && end >= existingStart;
  });
}

export function calculateNetPay(basic: number, hra: number, benefits: number, deductions: number): number {
  return Number((basic + hra + benefits - deductions).toFixed(2));
}


export function summarizeDashboardMetrics(
  employeeCount: number,
  attendanceRows: Array<{ workDate: Date | string; status: string; workMinutes: number | null }>,
  leaveRows: Array<{ status: string }>,
  payrollRows: Array<{ employeeId: number; payMonth: string; basic: string | number; hra: string | number; benefits: string | number; deductions: string | number }>,
) {
  const latestWorkDate = attendanceRows[0]?.workDate;
  const currentAttendance = latestWorkDate ? attendanceRows.filter((row) => String(row.workDate) === String(latestWorkDate)) : [];
  const plannedMinutes = currentAttendance.length * 480;
  const loggedMinutes = currentAttendance.reduce((sum, row) => sum + (row.workMinutes ?? 0), 0);
  const presentCount = currentAttendance.filter((row) => row.status === "present").length;
  const pendingLeaveCount = leaveRows.filter((row) => row.status === "pending").length;
  const payrollEmployees = new Set(payrollRows.map((row) => row.employeeId)).size;
  const latestPayroll = payrollRows[0];
  const latestNetPay = latestPayroll ? Number((Number(latestPayroll.basic) + Number(latestPayroll.hra) + Number(latestPayroll.benefits) - Number(latestPayroll.deductions)).toFixed(2)) : 0;
  return {
    peopleTotal: employeeCount,
    peopleAtWork: presentCount,
    loggedMinutes,
    plannedMinutes,
    attendanceRate: employeeCount ? Math.round((presentCount / employeeCount) * 100) : 0,
    pendingLeaveCount,
    attendanceRecordCount: attendanceRows.length,
    leaveRequestCount: leaveRows.length,
    payrollReadiness: employeeCount ? Math.min(100, Math.round((payrollEmployees / employeeCount) * 100)) : 0,
    latestPayMonth: latestPayroll?.payMonth ?? null,
    latestNetPay,
  };
}

export type DashboardConnectionMode = "live" | "reconnecting" | "offline";

export function readDashboardCache<T>(storage: Pick<Storage, "getItem"> | null, key = "dayflow-dashboard-cache"): T | undefined {
  if (!storage) return undefined;
  try {
    const raw = storage.getItem(key);
    return raw ? JSON.parse(raw) as T : undefined;
  } catch {
    return undefined;
  }
}

export function writeDashboardCache<T>(storage: Pick<Storage, "setItem"> | null, data: T, key = "dayflow-dashboard-cache"): void {
  if (!storage) return;
  try { storage.setItem(key, JSON.stringify(data)); } catch { /* Ignore unavailable browser storage. */ }
}

export function getDashboardConnectionMode(input: { isOnline: boolean; isFetching: boolean; hasError: boolean; hasCache: boolean }): DashboardConnectionMode {
  if (input.isFetching) return "reconnecting";
  if (!input.isOnline || (input.hasError && input.hasCache)) return "offline";
  return "live";
}

export function shouldAnnounceReconnect(previous: DashboardConnectionMode, current: DashboardConnectionMode): boolean {
  return previous !== "live" && current === "live";
}

export function formatLastSynced(timestamp: number | undefined, locale?: string): string {
  if (!timestamp) return "";
  return new Date(timestamp).toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" });
}

export function getLoginDestination(isAuthenticated: boolean): "/" | "/login" {
  return isAuthenticated ? "/" : "/login";
}

export function getLoginButtonLabel(isLoading: boolean): string {
  return isLoading ? "Checking session…" : "Continue with Google";
}

export function getAuthRecoveryMessage(reason: string, hasSessionError = false): string {
  if (/cancel|denied|access_denied/i.test(reason)) return "Sign-in was cancelled. You can try again whenever you’re ready.";
  if (/expired|invalid|state|timeout/i.test(reason)) return "That sign-in link has expired. Start a fresh secure sign-in to continue.";
  return hasSessionError ? "We couldn’t verify your session. Please try again." : "";
}

export function toggleChecklistItem(items: string[], id: string): string[] {
  return items.includes(id) ? items.filter((item) => item !== id) : [...items, id];
}

export type DayflowStorage = Pick<Storage, "getItem" | "setItem">;

export function persistSelectedWorkspace(storage: DayflowStorage, workspace: string): void {
  storage.setItem("dayflow-selected-workspace", workspace);
}

export function readChecklistProgress(storage: DayflowStorage): string[] {
  try {
    const value = storage.getItem("dayflow-admin-checklist");
    return value ? JSON.parse(value) : [];
  } catch {
    return [];
  }
}

export function persistChecklistProgress(storage: DayflowStorage, items: string[]): void {
  storage.setItem("dayflow-admin-checklist", JSON.stringify(items));
  if (items.length === 4) storage.setItem("dayflow-admin-onboarding-complete", "true");
}

export function runWorkspaceLogin(
  storage: DayflowStorage,
  workspace: string,
  launch: () => void,
): void {
  persistSelectedWorkspace(storage, workspace);
  launch();
}
