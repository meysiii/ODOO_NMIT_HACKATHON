import { describe, expect, it } from "vitest";
import { calculateLeaveDays, calculateNetPay, calculateWorkMinutes, hasLeaveOverlap } from "./dayflow";

describe("Dayflow business rules", () => {
  it("calculates work hours from check-in and check-out timestamps", () => {
    expect(calculateWorkMinutes(new Date("2026-08-18T09:12:00Z"), new Date("2026-08-18T17:42:00Z"))).toBe(510);
  });

  it("rejects inverted leave ranges and counts inclusive days", () => {
    expect(calculateLeaveDays("2026-08-20", "2026-08-22")).toBe(3);
    expect(calculateLeaveDays("2026-08-22", "2026-08-20")).toBe(0);
  });

  it("detects overlap only against active requests", () => {
    const records = [
      { startDate: "2026-08-20", endDate: "2026-08-22", status: "pending" as const },
      { startDate: "2026-08-25", endDate: "2026-08-26", status: "rejected" as const },
    ];
    expect(hasLeaveOverlap("2026-08-22", "2026-08-23", records)).toBe(true);
    expect(hasLeaveOverlap("2026-08-25", "2026-08-26", records)).toBe(false);
  });

  it("keeps net pay calculation transparent", () => {
    expect(calculateNetPay(84000, 30000, 18000, 7200)).toBe(124800);
  });
});
