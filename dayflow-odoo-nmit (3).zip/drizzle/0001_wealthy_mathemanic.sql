CREATE TABLE `attendance` (
	`id` int AUTO_INCREMENT NOT NULL,
	`employeeId` int NOT NULL,
	`workDate` date NOT NULL,
	`checkIn` timestamp,
	`checkOut` timestamp,
	`workMinutes` int NOT NULL DEFAULT 0,
	`status` enum('present','absent','half-day','leave') NOT NULL DEFAULT 'absent',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `attendance_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `employees` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`employeeId` varchar(32) NOT NULL,
	`fullName` varchar(160) NOT NULL,
	`email` varchar(320) NOT NULL,
	`phone` varchar(40),
	`address` text,
	`role` enum('hr','employee') NOT NULL DEFAULT 'employee',
	`jobTitle` varchar(120),
	`department` varchar(80),
	`avatarUrl` text,
	`verificationReady` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `employees_id` PRIMARY KEY(`id`),
	CONSTRAINT `employees_employeeId_unique` UNIQUE(`employeeId`)
);
--> statement-breakpoint
CREATE TABLE `leaveRequests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`employeeId` int NOT NULL,
	`type` enum('paid','sick','unpaid') NOT NULL,
	`startDate` date NOT NULL,
	`endDate` date NOT NULL,
	`days` decimal(5,1) NOT NULL,
	`remarks` text,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`hrComment` text,
	`reviewedBy` int,
	`reviewedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `leaveRequests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `payroll` (
	`id` int AUTO_INCREMENT NOT NULL,
	`employeeId` int NOT NULL,
	`payMonth` varchar(7) NOT NULL,
	`basic` decimal(12,2) NOT NULL,
	`hra` decimal(12,2) NOT NULL DEFAULT '0',
	`benefits` decimal(12,2) NOT NULL DEFAULT '0',
	`deductions` decimal(12,2) NOT NULL DEFAULT '0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `payroll_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `pulseSignals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`signalType` varchar(50) NOT NULL,
	`title` varchar(180) NOT NULL,
	`evidence` text NOT NULL,
	`recommendedAction` text,
	`visibility` enum('hr-only','team-aggregate') NOT NULL DEFAULT 'team-aggregate',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `pulseSignals_id` PRIMARY KEY(`id`)
);
