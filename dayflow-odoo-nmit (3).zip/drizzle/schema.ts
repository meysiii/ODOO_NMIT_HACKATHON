import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, date, boolean } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  passwordHash: text("passwordHash"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const employees = mysqlTable("employees", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  employeeId: varchar("employeeId", { length: 32 }).notNull().unique(),
  fullName: varchar("fullName", { length: 160 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 40 }),
  address: text("address"),
  role: mysqlEnum("role", ["hr", "employee"]).default("employee").notNull(),
  jobTitle: varchar("jobTitle", { length: 120 }),
  department: varchar("department", { length: 80 }),
  avatarUrl: text("avatarUrl"),
  verificationReady: boolean("verificationReady").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const attendance = mysqlTable("attendance", {
  id: int("id").autoincrement().primaryKey(),
  employeeId: int("employeeId").notNull(),
  workDate: date("workDate").notNull(),
  checkIn: timestamp("checkIn"),
  checkOut: timestamp("checkOut"),
  workMinutes: int("workMinutes").default(0).notNull(),
  status: mysqlEnum("status", ["present", "absent", "half-day", "leave"]).default("absent").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const leaveRequests = mysqlTable("leaveRequests", {
  id: int("id").autoincrement().primaryKey(),
  employeeId: int("employeeId").notNull(),
  type: mysqlEnum("type", ["paid", "sick", "unpaid"]).notNull(),
  startDate: date("startDate").notNull(),
  endDate: date("endDate").notNull(),
  days: decimal("days", { precision: 5, scale: 1 }).notNull(),
  remarks: text("remarks"),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  hrComment: text("hrComment"),
  reviewedBy: int("reviewedBy"),
  reviewedAt: timestamp("reviewedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const payroll = mysqlTable("payroll", {
  id: int("id").autoincrement().primaryKey(),
  employeeId: int("employeeId").notNull(),
  payMonth: varchar("payMonth", { length: 7 }).notNull(),
  basic: decimal("basic", { precision: 12, scale: 2 }).notNull(),
  hra: decimal("hra", { precision: 12, scale: 2 }).default("0").notNull(),
  benefits: decimal("benefits", { precision: 12, scale: 2 }).default("0").notNull(),
  deductions: decimal("deductions", { precision: 12, scale: 2 }).default("0").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  body: text("body").notNull(),
  kind: varchar("kind", { length: 32 }).default("info").notNull(),
  readAt: timestamp("readAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const pulseSignals = mysqlTable("pulseSignals", {
  id: int("id").autoincrement().primaryKey(),
  signalType: varchar("signalType", { length: 50 }).notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  evidence: text("evidence").notNull(),
  recommendedAction: text("recommendedAction"),
  visibility: mysqlEnum("visibility", ["hr-only", "team-aggregate"]).default("team-aggregate").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Employee = typeof employees.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
