import { describe, expect, it } from "vitest";
import { hashPassword, normalizeLoginIdentifier, verifyPassword } from "./credentials";

describe("credential authentication helpers", () => {
  it("hashes passwords without retaining the plaintext and verifies them", async () => {
    const encoded = await hashPassword("correct-horse-battery-staple");
    expect(encoded).not.toContain("correct-horse");
    expect(await verifyPassword("correct-horse-battery-staple", encoded)).toBe(true);
    expect(await verifyPassword("wrong-password", encoded)).toBe(false);
  });

  it("normalizes email identifiers without changing employee IDs", () => {
    expect(normalizeLoginIdentifier("  HR@Example.COM ")).toBe("hr@example.com");
    expect(normalizeLoginIdentifier(" DF-2048 ")).toBe("df-2048");
  });
});
