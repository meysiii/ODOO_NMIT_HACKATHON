import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { formatLastSynced, getDashboardConnectionMode, readDashboardCache, shouldAnnounceReconnect, writeDashboardCache } from "../shared/dayflow";

describe("dashboard offline resilience", () => {
  it("persists and hydrates a dashboard snapshot", () => {
    const values = new Map<string, string>();
    const storage = {
      getItem: (key: string) => values.get(key) ?? null,
      setItem: (key: string, value: string) => values.set(key, value),
    };
    const snapshot = { metrics: { peopleTotal: 4 }, employees: [] };

    writeDashboardCache(storage, snapshot);
    expect(readDashboardCache<typeof snapshot>(storage)).toEqual(snapshot);
  });

  it("announces restored live data and formats cache freshness", () => {
    expect(shouldAnnounceReconnect("offline", "live")).toBe(true);
    expect(shouldAnnounceReconnect("reconnecting", "live")).toBe(true);
    expect(shouldAnnounceReconnect("live", "live")).toBe(false);
    expect(formatLastSynced(Date.UTC(2026, 0, 2, 13, 5), "en-GB")).toBe("13:05");
  });

  it("keeps reconnect and motion styling contracts present", () => {
    const css = readFileSync(resolve(process.cwd(), "client/src/index.css"), "utf8");
    expect(css).toContain("reconnected-flash");
    expect(css).toContain("dayflow-reconnect-glow");
    expect(css).toContain(".summary-card:hover");
    expect(css).toContain("dayflow-bar-rise");
    expect(css).toContain("prefers-reduced-motion:reduce");
  });

  it("selects reconnecting, offline, and live UI modes deterministically", () => {
    expect(getDashboardConnectionMode({ isOnline: true, isFetching: true, hasError: false, hasCache: true })).toBe("reconnecting");
    expect(getDashboardConnectionMode({ isOnline: false, isFetching: false, hasError: true, hasCache: true })).toBe("offline");
    expect(getDashboardConnectionMode({ isOnline: true, isFetching: false, hasError: false, hasCache: false })).toBe("live");
  });
});
