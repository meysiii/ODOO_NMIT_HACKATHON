import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("dashboard fetch resilience", () => {
  it("gates protected queries and retries transient fetch failures", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/Home.tsx"), "utf8");

    expect(source).toContain("enabled: isAuthenticated");
    expect(source).toContain("retry: 2");
    expect(source).toContain("retryDelay: (attempt) => Math.min(1000 * 2 ** attempt, 4000)");
  });
});
