import { and, desc, eq, isNull } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { randomUUID } from "node:crypto";
import { attendance, employees, InsertUser, leaveRequests, notifications, payroll, pulseSignals, users } from "../drizzle/schema";
import { ENV } from "./_core/env";
import { summarizeDashboardMetrics } from "@shared/dayflow";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); } catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; }
  }
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
  values.lastSignedIn ??= new Date();
  updateSet.lastSignedIn ??= new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) { const db = await getDb(); if (!db) return undefined; const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1); return result[0]; }

export async function getCredentialUser(identifier: string) {
  const db = await getDb();
  if (!db) return undefined;
  const normalized = identifier.trim().toLowerCase();
  const byEmail = await db.select().from(users).where(eq(users.email, normalized)).limit(1);
  if (byEmail[0]) return byEmail[0];
  const employeeRows = await db.select().from(employees).where(eq(employees.employeeId, identifier.trim())).limit(1);
  const employee = employeeRows[0];
  if (!employee?.userId) return undefined;
  const byEmployee = await db.select().from(users).where(eq(users.id, employee.userId)).limit(1);
  return byEmployee[0];
}

export async function createCredentialAccount(input: { name: string; email: string; passwordHash: string; role: "user" | "admin"; employeeId: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const openId = `credential_${randomUUID()}`;
  await db.insert(users).values({ openId, name: input.name.trim(), email: input.email.trim().toLowerCase(), passwordHash: input.passwordHash, role: input.role, loginMethod: "password" });
  const user = await getUserByOpenId(openId);
  if (!user) throw new Error("Account creation failed");
  await db.insert(employees).values({ userId: user.id, employeeId: input.employeeId.trim(), fullName: input.name.trim(), email: input.email.trim().toLowerCase(), role: input.role === "admin" ? "hr" : "employee", verificationReady: false });
  return user;
}
export async function getEmployeeByUserId(userId: number) { const db = await getDb(); if (!db) return undefined; const result = await db.select().from(employees).where(eq(employees.userId, userId)).limit(1); return result[0]; }
export async function listEmployees() { const db = await getDb(); if (!db) return []; return db.select().from(employees).orderBy(employees.fullName); }
export async function listAttendance(employeeId?: number) { const db = await getDb(); if (!db) return []; return db.select().from(attendance).where(employeeId ? eq(attendance.employeeId, employeeId) : undefined).orderBy(desc(attendance.workDate)); }
export async function listLeaveRequests(employeeId?: number) { const db = await getDb(); if (!db) return []; return db.select().from(leaveRequests).where(employeeId ? eq(leaveRequests.employeeId, employeeId) : undefined).orderBy(desc(leaveRequests.createdAt)); }
export async function listPayroll(employeeId?: number) { const db = await getDb(); if (!db) return []; return db.select().from(payroll).where(employeeId ? eq(payroll.employeeId, employeeId) : undefined).orderBy(desc(payroll.payMonth)); }
export async function listPulseSignals() { const db = await getDb(); if (!db) return []; return db.select().from(pulseSignals).orderBy(desc(pulseSignals.createdAt)); }

export async function getDashboardData(employeeId?: number) {
  const [employeeRows, attendanceRows, leaveRows, payrollRows] = await Promise.all([
    employeeId ? dbListEmployees(employeeId) : listEmployees(),
    listAttendance(employeeId),
    listLeaveRequests(employeeId),
    listPayroll(employeeId),
  ]);
  return {
    employees: employeeRows,
    attendance: attendanceRows,
    leaveRequests: leaveRows,
    payroll: payrollRows,
    metrics: summarizeDashboardMetrics(employeeRows.length, attendanceRows, leaveRows, payrollRows),
  };
}

async function dbListEmployees(employeeId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(employees).where(eq(employees.id, employeeId));
}

export async function listNotifications(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.createdAt));
}

export async function markNotificationRead(userId: number, id: number) {
  const db = await getDb();
  if (!db) return undefined;
  await db.update(notifications).set({ readAt: new Date() }).where(and(eq(notifications.id, id), eq(notifications.userId, userId), isNull(notifications.readAt)));
  const result = await db.select().from(notifications).where(and(eq(notifications.id, id), eq(notifications.userId, userId))).limit(1);
  return result[0];
}

export async function markAllNotificationsRead(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  await db.update(notifications).set({ readAt: new Date() }).where(and(eq(notifications.userId, userId), isNull(notifications.readAt)));
  return 1;
}

export async function getAttendanceForDate(employeeId: number, workDate: Date) { const db = await getDb(); if (!db) return undefined; const result = await db.select().from(attendance).where(and(eq(attendance.employeeId, employeeId), eq(attendance.workDate, workDate))).limit(1); return result[0]; }
export async function createAttendance(row: typeof attendance.$inferInsert) { const db = await getDb(); if (!db) return undefined; await db.insert(attendance).values(row); const employee = await getEmployeeById(row.employeeId); if (employee?.userId) await createNotification({ userId: employee.userId, title: "Check-in recorded", body: `Your attendance for ${String(row.workDate)} is now in the live record.`, kind: "success" }); return getAttendanceForDate(row.employeeId, row.workDate); }
export async function updateAttendance(id: number, row: Partial<typeof attendance.$inferInsert>) { const db = await getDb(); if (!db) return undefined; await db.update(attendance).set(row).where(eq(attendance.id, id)); const result = await db.select().from(attendance).where(eq(attendance.id, id)).limit(1); const employee = result[0] ? await getEmployeeById(result[0].employeeId) : undefined; if (employee?.userId && row.checkOut) await createNotification({ userId: employee.userId, title: "Check-out recorded", body: `Your workday closed after ${row.workMinutes ?? result[0]?.workMinutes ?? 0} minutes.`, kind: "info" }); return result[0]; }
export async function createNotification(row: typeof notifications.$inferInsert) { const db = await getDb(); if (!db) return undefined; await db.insert(notifications).values(row); return row; }
export async function getEmployeeById(id: number) { const db = await getDb(); if (!db) return undefined; const result = await db.select().from(employees).where(eq(employees.id, id)).limit(1); return result[0]; }
export async function createLeaveRequest(row: typeof leaveRequests.$inferInsert) { const db = await getDb(); if (!db) return undefined; await db.insert(leaveRequests).values(row); const employee = await getEmployeeById(row.employeeId); if (employee?.userId) await createNotification({ userId: employee.userId, title: "Leave request submitted", body: `Your ${row.type} leave request is now in the HR inbox.`, kind: "info" }); return listLeaveRequests(row.employeeId); }
export async function reviewLeaveRequest(id: number, status: "approved" | "rejected", hrComment: string | undefined, reviewedBy: number) { const db = await getDb(); if (!db) return undefined; await db.update(leaveRequests).set({ status, hrComment, reviewedBy, reviewedAt: new Date() }).where(eq(leaveRequests.id, id)); const result = await db.select().from(leaveRequests).where(eq(leaveRequests.id, id)).limit(1); const employee = result[0] ? await getEmployeeById(result[0].employeeId) : undefined; if (employee?.userId) await createNotification({ userId: employee.userId, title: `Leave request ${status}`, body: hrComment || `Your ${result[0]?.type ?? "leave"} request has been ${status}.`, kind: status === "approved" ? "success" : "warning" }); return result[0]; }
