import { describe, expect, it } from "vitest";

type Role = "hr" | "employee";
function canReadAttendance(viewer: Role, viewerEmployeeId: string, recordEmployeeId: string) { return viewer === "hr" || viewerEmployeeId === recordEmployeeId; }
function editableProfileFields(role: Role) { return role === "hr" ? ["fullName", "email", "phone", "address", "jobTitle", "department", "salary"] : ["phone", "address", "avatarUrl"]; }

describe("Dayflow role permissions", () => {
  it("limits employees to their own attendance while HR can inspect the team", () => {
    expect(canReadAttendance("employee", "DF-2048", "DF-2048")).toBe(true);
    expect(canReadAttendance("employee", "DF-2048", "DF-2049")).toBe(false);
    expect(canReadAttendance("hr", "DF-2049", "DF-2048")).toBe(true);
  });
  it("keeps employee profile edits restricted", () => {
    expect(editableProfileFields("employee")).toEqual(["phone", "address", "avatarUrl"]);
    expect(editableProfileFields("employee")).not.toContain("salary");
    expect(editableProfileFields("hr")).toContain("salary");
  });
});
