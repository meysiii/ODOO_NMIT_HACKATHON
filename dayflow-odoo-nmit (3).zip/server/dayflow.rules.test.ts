import { describe, expect, it } from "vitest";
import { calculateLeaveDays, calculateNetPay, calculateWorkMinutes, hasLeaveOverlap } from "../shared/dayflow";

describe("Dayflow business rules", () => {
  it("calculates work minutes from timestamps", () => {
    expect(calculateWorkMinutes(new Date("2026-08-18T09:12:00Z"), new Date("2026-08-18T17:42:00Z"))).toBe(510);
  });
  it("validates inclusive leave ranges", () => {
    expect(calculateLeaveDays("2026-08-20", "2026-08-22")).toBe(3);
    expect(calculateLeaveDays("2026-08-22", "2026-08-20")).toBe(0);
  });
  it("detects overlap for pending and approved requests only", () => {
    expect(hasLeaveOverlap("2026-08-22", "2026-08-23", [{ startDate: "2026-08-20", endDate: "2026-08-22", status: "pending" }])).toBe(true);
    expect(hasLeaveOverlap("2026-08-25", "2026-08-26", [{ startDate: "2026-08-25", endDate: "2026-08-26", status: "rejected" }])).toBe(false);
  });
  it("computes net pay from visible components", () => {
    expect(calculateNetPay(84000, 30000, 18000, 7200)).toBe(124800);
  });
});
