import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { eq, sql } from "drizzle-orm";
import { employees, users } from "../drizzle/schema";
import { getDb } from "./db";
import { verifyPassword } from "./credentials";

describe("employee directory identity presentation", () => {
  it("uses the neutral HR Manager identity instead of a named persona", () => {
    const home = readFileSync(resolve(process.cwd(), "client/src/pages/Home.tsx"), "utf8");
    expect(home).not.toContain("Maya Iyer");
    expect(home).toContain('"HR Manager"');
    expect(home).toContain('"HR MANAGER"');
  });

  it("contains the requested seeded employee range and employee account", async () => {
    const db = await getDb();
    if (!db) return;
    const countRows = await db.select({ count: sql<number>`count(*)` }).from(employees).where(sql`employeeId >= 'DF-3001' AND employeeId <= 'DF-3050'`);
    expect(Number(countRows[0]?.count)).toBe(50);
    const accountRows = await db.select({ email: users.email, userRole: users.role, employeeId: employees.employeeId, fullName: employees.fullName, employeeRole: employees.role })
      .from(users).leftJoin(employees, eq(employees.userId, users.id)).where(eq(users.email, "meysintha2006@gmail.com"));
    expect(accountRows[0]).toMatchObject({ email: "meysintha2006@gmail.com", userRole: "user", employeeId: "DF-3051", fullName: "Meisintha Suresh", employeeRole: "employee" });
  });

  it("verifies the stored requested employee password through the credential helper", async () => {
    const storedHash = "466e3efafb2ec106a7485fb9b142dca6:9b964e3fd4a17981aa2c6a1cd474ee185bb8a6a7a9fcd2f72bbe52defb3bb1fd029fcd265fe79320686e931ae9ee0b7ba6bf754d2868f17aff893f9cf361c688";
    expect(await verifyPassword("meysintha06", storedHash)).toBe(true);
    expect(await verifyPassword("wrong-password", storedHash)).toBe(false);
  });
});
