import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { appRouter } from "./routers";

const homeSource = readFileSync(resolve(process.cwd(), "client/src/pages/Home.tsx"), "utf8");
const themeSource = readFileSync(resolve(process.cwd(), "client/src/contexts/ThemeContext.tsx"), "utf8");
const dbSource = readFileSync(resolve(process.cwd(), "server/db.ts"), "utf8");

describe("Dayflow live data contracts", () => {
  it("exposes the dashboard and notification routers", () => {
    const procedures = Object.keys(appRouter._def.procedures);
    expect(procedures).toContain("dashboard.data");
    expect(procedures).toContain("notifications.list");
  });

  it("exposes notification read-state procedures", () => {
    const procedures = Object.keys(appRouter._def.procedures);
    expect(procedures).toEqual(expect.arrayContaining(["notifications.list", "notifications.markRead", "notifications.markAllRead"]));
  });

  it("keeps the theme and live-event contracts wired", () => {
    expect(themeSource).toContain('localStorage.getItem("theme")');
    expect(homeSource).toContain("Syncing live people, attendance, leave, and payroll records");
    expect(dbSource).toContain('title: "Check-in recorded"');
    expect(dbSource).toContain('title: "Leave request submitted"');
  });
});
