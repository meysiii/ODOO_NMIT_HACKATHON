import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { createAttendance, createLeaveRequest, getAttendanceForDate, getEmployeeByUserId, listAttendance, listEmployees, listLeaveRequests, listPayroll, listPulseSignals, reviewLeaveRequest, updateAttendance } from "./db";
import { calculateWorkMinutes, hasLeaveOverlap } from "@shared/dayflow";
import { createCredentialAccount, getCredentialUser, getDashboardData, listNotifications, markAllNotificationsRead, markNotificationRead, upsertUser } from "./db";
import { hashPassword, verifyPassword } from "./credentials";
import { sdk } from "./_core/sdk";
import { ENV } from "./_core/env";

const dateSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use YYYY-MM-DD");
const adminOnly = adminProcedure;

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => { const cookieOptions = getSessionCookieOptions(ctx.req); ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 }); return { success: true } as const; }),
    credentialSignIn: publicProcedure.input(z.object({ identifier: z.string().min(1).max(320), password: z.string().min(1).max(200), mode: z.enum(["employee", "hr"]) })).mutation(async ({ ctx, input }) => {
      const user = await getCredentialUser(input.identifier);
      const expectedRole = input.mode === "hr" ? "admin" : "user";
      if (!user || user.role !== expectedRole || !(await verifyPassword(input.password, user.passwordHash))) throw new Error("We couldn’t sign you in with those details. Check your ID, email, password, and login type.");
      await upsertUser({ openId: user.openId, lastSignedIn: new Date() });
      const token = await sdk.signSession({ openId: user.openId, appId: ENV.appId, name: user.name ?? "" });
      ctx.res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(ctx.req), maxAge: 1000 * 60 * 60 * 24 * 365 });
      return { success: true } as const;
    }),
    credentialSignUp: publicProcedure.input(z.object({ name: z.string().min(2).max(160), email: z.string().email().max(320), password: z.string().min(8).max(200), employeeId: z.string().min(2).max(32), mode: z.enum(["employee", "hr"]) })).mutation(async ({ input }) => {
      if (input.mode === "hr") throw new Error("HR administrator accounts require an organization invite or an existing admin approval.");
      const normalizedEmail = input.email.trim().toLowerCase();
      if (await getCredentialUser(normalizedEmail) || await getCredentialUser(input.employeeId)) throw new Error("An account already exists for that email or employee ID.");
      await createCredentialAccount({ name: input.name, email: normalizedEmail, passwordHash: await hashPassword(input.password), role: "user", employeeId: input.employeeId });
      return { success: true } as const;
    }),
    adminCreateHrAccount: adminProcedure.input(z.object({ name: z.string().min(2).max(160), email: z.string().email().max(320), password: z.string().min(8).max(200), employeeId: z.string().min(2).max(32) })).mutation(async ({ input }) => {
      const normalizedEmail = input.email.trim().toLowerCase();
      if (await getCredentialUser(normalizedEmail) || await getCredentialUser(input.employeeId)) throw new Error("An account already exists for that email or employee ID.");
      await createCredentialAccount({ name: input.name, email: normalizedEmail, passwordHash: await hashPassword(input.password), role: "admin", employeeId: input.employeeId });
      return { success: true } as const;
    }),
  }),
  dashboard: router({
    data: protectedProcedure.query(async ({ ctx }) => {
      const employee = await getEmployeeByUserId(ctx.user.id);
      return getDashboardData(ctx.user.role === "admin" ? undefined : employee?.id);
    }),
  }),
  notifications: router({
    list: protectedProcedure.query(({ ctx }) => listNotifications(ctx.user.id)),
    markRead: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ ctx, input }) => markNotificationRead(ctx.user.id, input.id)),
    markAllRead: protectedProcedure.mutation(({ ctx }) => markAllNotificationsRead(ctx.user.id)),
  }),
  employees: router({
    list: adminOnly.query(() => listEmployees()),
    me: protectedProcedure.query(({ ctx }) => getEmployeeByUserId(ctx.user.id)),
  }),
  attendance: router({
    mine: protectedProcedure.query(async ({ ctx }) => { const employee = await getEmployeeByUserId(ctx.user.id); return employee ? listAttendance(employee.id) : []; }),
    team: adminOnly.query(() => listAttendance()),
    checkIn: protectedProcedure.input(z.object({ workDate: dateSchema })).mutation(async ({ ctx, input }) => { const employee = await getEmployeeByUserId(ctx.user.id); if (!employee) throw new Error("Employee profile not found"); const existing = await getAttendanceForDate(employee.id, new Date(`${input.workDate}T00:00:00Z`)); if (existing?.checkIn) throw new Error("Already checked in for this day"); return createAttendance({ employeeId: employee.id, workDate: new Date(`${input.workDate}T00:00:00Z`), checkIn: new Date(), status: "present", workMinutes: 0 }); }),
    checkOut: protectedProcedure.input(z.object({ workDate: dateSchema, attendanceId: z.number().int().positive(), checkIn: z.coerce.date() })).mutation(({ input }) => { const checkOut = new Date(); const workMinutes = calculateWorkMinutes(input.checkIn, checkOut); return updateAttendance(input.attendanceId, { checkOut, workMinutes, status: workMinutes >= 240 ? "present" : "half-day" }); }),
  }),
  leave: router({
    mine: protectedProcedure.query(async ({ ctx }) => { const employee = await getEmployeeByUserId(ctx.user.id); return employee ? listLeaveRequests(employee.id) : []; }),
    inbox: adminOnly.query(() => listLeaveRequests()),
    create: protectedProcedure.input(z.object({ type: z.enum(["paid", "sick", "unpaid"]), startDate: dateSchema, endDate: dateSchema, days: z.number().positive(), remarks: z.string().max(500).optional() }).refine((value) => value.endDate >= value.startDate, { message: "End date must be on or after start date" })).mutation(async ({ ctx, input }) => { const employee = await getEmployeeByUserId(ctx.user.id); if (!employee) throw new Error("Employee profile not found"); const existing = await listLeaveRequests(employee.id); if (hasLeaveOverlap(input.startDate, input.endDate, existing.map((request) => ({ startDate: String(request.startDate), endDate: String(request.endDate), status: request.status })) )) throw new Error("Leave dates overlap an active request"); return createLeaveRequest({ employeeId: employee.id, type: input.type, startDate: new Date(`${input.startDate}T00:00:00Z`), endDate: new Date(`${input.endDate}T00:00:00Z`), days: String(input.days), remarks: input.remarks, status: "pending" }); }),
    review: adminOnly.input(z.object({ id: z.number().int().positive(), status: z.enum(["approved", "rejected"]), hrComment: z.string().max(500).optional() })).mutation(({ ctx, input }) => reviewLeaveRequest(input.id, input.status, input.hrComment, ctx.user.id)),
  }),
  payroll: router({
    mine: protectedProcedure.query(async ({ ctx }) => { const employee = await getEmployeeByUserId(ctx.user.id); return employee ? listPayroll(employee.id) : []; }),
    team: adminOnly.query(() => listPayroll()),
  }),
  pulse: router({ signals: adminOnly.query(() => listPulseSignals()) }),
});

export type AppRouter = typeof appRouter;
