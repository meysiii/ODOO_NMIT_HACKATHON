import { describe, expect, it, vi } from "vitest";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";

const authState = vi.hoisted(() => ({ user: null as unknown, loading: false, error: null as unknown }));

vi.mock("@/_core/hooks/useAuth", () => ({ useAuth: () => authState }));
vi.mock("@/const", () => ({ startLogin: vi.fn() }));
vi.mock("wouter", () => ({ useLocation: () => ["/login", vi.fn()] }));
vi.mock("@/lib/trpc", () => ({ trpc: { auth: { credentialSignIn: { useMutation: () => ({ mutate: vi.fn(), isPending: false, error: null }) }, credentialSignUp: { useMutation: () => ({ mutate: vi.fn(), isPending: false, error: null }) } } } }));

describe("rendered Dayflow login", () => {
  it("renders the branded sign-in CTA and session error state", async () => {
    const { default: Login } = await import("../client/src/pages/Login");
    authState.error = new Error("session unavailable");

    const markup = renderToStaticMarkup(createElement(Login));

    expect(markup).toContain("Make work feel");
    expect(markup).toContain("Continue with Google");
    expect(markup).toContain("We couldn’t verify your session");
    expect(markup).toContain("login-button");
  });

  it("renders dedicated HR and Employee modes with separate credential boxes", async () => {
    const { default: Login } = await import("../client/src/pages/Login");
    authState.error = null;

    const employeeMarkup = renderToStaticMarkup(createElement(Login, { defaultMode: "employee" }));
    const hrMarkup = renderToStaticMarkup(createElement(Login, { defaultMode: "hr" }));

    expect(employeeMarkup).toContain('aria-selected="true">Employee</button>');
    expect(employeeMarkup).toContain("EMAIL OR EMPLOYEE ID");
    expect(employeeMarkup).toContain('type="password"');
    expect(employeeMarkup).toContain('class="login-form"');
    expect(hrMarkup).toContain('aria-selected="true">HR administrator</button>');
    expect(hrMarkup).toContain("WORK EMAIL OR ADMIN ID");
    expect(hrMarkup).toContain('type="password"');
  });
});
