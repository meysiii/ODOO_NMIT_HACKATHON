import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { getAuthRecoveryMessage, getLoginButtonLabel, getLoginDestination, persistChecklistProgress, persistSelectedWorkspace, readChecklistProgress, runWorkspaceLogin, toggleChecklistItem } from "../shared/dayflow";

describe("Dayflow login page", () => {
  it("uses the authenticated destination and loading labels", () => {
    expect(getLoginDestination(true)).toBe("/");
    expect(getLoginDestination(false)).toBe("/login");
    expect(getLoginButtonLabel(true)).toBe("Checking session…");
    expect(getLoginButtonLabel(false)).toBe("Continue with Google");
  });

  it("maps OAuth failures to friendly recovery copy and toggles checklist progress", () => {
    expect(getAuthRecoveryMessage("access_denied")).toContain("cancelled");
    expect(getAuthRecoveryMessage("invalid_state")).toContain("expired");
    expect(getAuthRecoveryMessage("", true)).toContain("verify your session");
    expect(toggleChecklistItem([], "workspace")).toEqual(["workspace"]);
    expect(toggleChecklistItem(["workspace"], "workspace")).toEqual([]);
    const values = new Map<string, string>();
    const storage = { getItem: (key: string) => values.get(key) ?? null, setItem: (key: string, value: string) => values.set(key, value) };
    persistSelectedWorkspace(storage, "Lumen Studio");
    expect(values.get("dayflow-selected-workspace")).toBe("Lumen Studio");
    const events: string[] = [];
    runWorkspaceLogin(storage, "Lumen Studio", () => events.push(values.get("dayflow-selected-workspace") ?? "missing"));
    expect(events).toEqual(["Lumen Studio"]);
    persistChecklistProgress(storage, ["workspace"]);
    expect(readChecklistProgress(storage)).toEqual(["workspace"]);
  });

  it("registers the login route and connects the OAuth CTA", () => {
    const appSource = readFileSync(resolve(process.cwd(), "client/src/App.tsx"), "utf8");
    const loginSource = readFileSync(resolve(process.cwd(), "client/src/pages/Login.tsx"), "utf8");

    expect(appSource).toContain('<Route path="/login/hr" component={HrLoginPage} />');
    expect(appSource).toContain('<Route path="/login/employee" component={EmployeeLoginPage} />');
    expect(appSource).toContain('<Route path="/login" component={LoginPage} />');
    expect(loginSource).toContain('import { startLogin } from "@/const";');
    expect(loginSource).toContain("const handleSubmit = (event: React.FormEvent<HTMLFormElement>) =>");
    expect(loginSource).toContain("runWorkspaceLogin(window.localStorage, selectedWorkspace.name, startLogin)");
    expect(loginSource).toContain("getLoginDestination(Boolean(user))");
    expect(loginSource).toContain("workspace-options");
  });
});
