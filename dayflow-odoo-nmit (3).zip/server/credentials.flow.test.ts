import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("credential-first portal flow", () => {
  it("routes the root through an auth gate and keeps the login route public", () => {
    const app = readFileSync(resolve(process.cwd(), "client/src/App.tsx"), "utf8");
    expect(app).toContain("function HomeGate()");
    expect(app).toContain("if (loading || !isAuthenticated) return <Login />");
    expect(app).toContain('<Route path="/login/hr" component={HrLoginPage} />');
    expect(app).toContain('<Route path="/login/employee" component={EmployeeLoginPage} />');
    expect(app).toContain('<Route path="/login" component={LoginPage} />');
  });

  it("exposes credential sign-in and signup with role-safe HR registration", () => {
    const router = readFileSync(resolve(process.cwd(), "server/routers.ts"), "utf8");
    expect(router).toContain("credentialSignIn");
    expect(router).toContain("credentialSignUp");
    expect(router).toContain("adminCreateHrAccount");
    expect(router).toContain('if (input.mode === "hr") throw new Error');
    expect(router).toContain("verifyPassword");
    expect(router).toContain("ctx.res.cookie(COOKIE_NAME");
  });
});
