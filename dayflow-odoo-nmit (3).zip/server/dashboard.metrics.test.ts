import { describe, expect, it } from "vitest";
import { summarizeDashboardMetrics } from "../shared/dayflow";

describe("summarizeDashboardMetrics", () => {
  it("calculates current attendance, pending leave, payroll readiness, and net pay", () => {
    const metrics = summarizeDashboardMetrics(2, [
      { workDate: "2026-08-22", status: "present", workMinutes: 420 },
      { workDate: "2026-08-22", status: "leave", workMinutes: 0 },
      { workDate: "2026-08-21", status: "present", workMinutes: 480 },
    ], [{ status: "pending" }, { status: "approved" }], [{ employeeId: 1, payMonth: "2026-08", basic: "100", hra: "20", benefits: "5", deductions: "10" }]);
    expect(metrics.peopleAtWork).toBe(1);
    expect(metrics.loggedMinutes).toBe(420);
    expect(metrics.pendingLeaveCount).toBe(1);
    expect(metrics.payrollReadiness).toBe(50);
    expect(metrics.latestNetPay).toBe(115);
  });
});
