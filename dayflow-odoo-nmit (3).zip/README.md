# Dayflow — Human Resource Management System

> **Every workday, perfectly aligned.**

Dayflow is a polished workforce management platform for the ODOO-NMIT hackathon. It connects the complete employee-to-HR workflow in one calm workspace: role-aware access, employee self-service profiles, attendance, leave approvals, payroll visibility, and an explainable Workforce Pulse.

## Why Dayflow stands out

Most HRMS prototypes stop at CRUD screens. Dayflow adds a **transparent operational intelligence layer**. Workforce Pulse does not score, rank, diagnose, or profile people. It only turns existing operational records—attendance, approved time-off, and team hours—into visible cues with the evidence beside every cue and a recommended human action. HR can see what is happening without losing trust or control.

## Feature map

| Area | Employee experience | Admin / HR experience |
|---|---|---|
| Access | Employee ID, email, password, verification-ready status | HR role-aware workspace access |
| Profile | View personal/job/pay details; edit address, phone, photo | Edit complete employee records |
| Attendance | Check in/out; personal daily and weekly records | Inspect team attendance and hours |
| Leave | Paid, sick, unpaid requests with range validation | Approve/reject with comments; immediate record update |
| Payroll | Read-only salary components and net pay | Edit salary components and readiness |
| Workforce Pulse | Privacy principles visible by design | Evidence-backed operational signals and actions |

## Demo walkthrough

The fastest presentation path is to start in the HR workspace. Show the overview metrics, open the employee directory, switch to Leave & time-off, approve the pending request, and point out the immediate status update. Open Payroll to show the visible component calculation. Finish with Workforce Pulse: explain that “watchpoint” is not a hidden score; it is a traceable operational cue linked to pending requests and team planning.

Then use the **Viewing as HR** control in the top-right to switch to Employee. Show the employee-only attendance and payroll views, press Check in to demonstrate a live status transition, and open My profile to show the restricted editable fields. Close with the privacy principle: Dayflow helps HR act earlier while keeping decisions human and explainable.

## Architecture

The project uses the Manus full-stack template: React 19 and Tailwind CSS for the interface, Express and tRPC for typed server procedures, Drizzle ORM for the database model, and Manus OAuth for authentication. The schema includes `employees`, `attendance`, `leaveRequests`, `payroll`, and `pulseSignals`, in addition to the built-in `users` table. Role-guarded procedures cover employee self-reads, HR team reads, attendance check-in/out, leave creation/review, payroll reads, and Pulse signals. The current hackathon walkthrough also uses shared deterministic demo records for a reliable offline-friendly presentation.

## Role permissions

Employees may read their own profile, attendance, leave requests, and payroll information. They may edit only address, phone, and profile photo metadata. Admin/HR may read the employee directory, all attendance records, leave inbox, and payroll; they may edit complete employee records and approve or reject leave requests with comments. Workforce Pulse is aggregate-first and does not expose sensitive individual inferences.

## Demo access

The preview opens directly into a deterministic demo workspace so the presentation does not depend on an external mailbox or network verification step. Use the **Viewing as HR** control in the top-right to switch between the HR Administrator view and the Employee view. In production, the scaffolded Manus OAuth flow supplies the authenticated user and the database schema is ready to connect each session to a role-guarded employee record; no real passwords or credentials are committed to the repository.

## Local setup

```bash
pnpm install
pnpm dev
```

The application is available through the managed preview URL. Type-check and tests run with:

```bash
pnpm check
pnpm test
```

## Validation and tests

The project includes tests for authentication logout behavior, timestamp-based work-minute calculation, inclusive leave-day calculation, overlap protection that ignores rejected requests, transparent net-pay calculation, employee-versus-HR attendance visibility, and restricted employee profile fields. UI actions include success toasts, disabled/read-only fields where appropriate, responsive mobile navigation, explicit directory empty state, and onboarding field validation. `pnpm build` is also verified for release readiness.

## Submission notes

Use the latest project checkpoint as the source for GitHub export. Record a short screen capture using the demo walkthrough above. The core story is: **Dayflow moves HR from chasing records to seeing the next helpful action—without turning people into scores.**

## Future roadmap

A production extension would connect the typed procedures to seeded database records, add email verification and notifications, add downloadable payslips and attendance reports, and introduce configurable organization policies while preserving the same privacy and audit principles.
