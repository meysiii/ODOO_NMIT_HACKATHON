# Project TODO

- [x] Create the Dayflow visual system: refined navy/ink palette, warm canvas, accessible type scale, sidebar navigation, responsive cards, calendars, and motion polish.
- [x] Build role-aware onboarding/sign-in experience with Employee ID, email, password validation, verification-ready status, and Admin/HR versus Employee entry points.
- [x] Add database-backed employee profiles with personal details, job details, salary structure, documents, profile photo metadata, and role-based edit permissions.
- [x] Add database-backed attendance with check-in/check-out, automatic work-hours calculation, daily/weekly views, and Present/Absent/Half-day/Leave statuses.
- [x] Add role-guarded attendance visibility so employees see only their own records and HR can inspect all records.
- [x] Add paid/sick/unpaid leave requests with range validation, overlap protection, remarks, status transitions, and HR approval comments.
- [x] Make approved/rejected leave decisions update employee-facing records immediately.
- [x] Add payroll visibility with read-only employee views, HR salary-component editing, and transparent net-pay calculation.
- [x] Build the Admin/HR command center with employee switching, searchable directory, attendance records, pending approvals, and operational summaries.
- [x] Build Explainable Workforce Pulse with evidence-backed team signals, privacy guardrails, and recommended HR actions without opaque or medical claims.
- [x] Add realistic seeded demo records and a reliable employee-to-HR approval walkthrough.
- [x] Add loading, empty, error, success, validation, focus, and mobile states across the core flows.
- [x] Add Vitest coverage for validation, role permissions, attendance calculations, leave overlap logic, and payroll calculations.
- [x] Verify the app with typecheck, tests, dev preview screenshots, and responsive checks.
- [x] Write a concise README with setup, architecture, role permissions, demo credentials/data flow, and presentation path.
- [x] Save the final checkpoint for the user to submit/publish and provide a concise 90-second presentation script.

- [x] Resolve gap: implement real HR employee switching so selected employee context changes profile, attendance, leave, and payroll views.
- [x] Resolve gap: derive Workforce Pulse cues and evidence from shared attendance, leave, and workload records rather than isolated copy.
- [x] Resolve gap: add explicit loading, empty, error, and stronger validation states across core views.
- [x] Resolve gap: add Vitest cases for role-based visibility and restricted-field validation.
- [x] Resolve gap: document concrete demo access instructions and clarify OAuth/demo mode in README.
- [x] Resolve gap: refactor Workforce Pulse to shared attendance, leave-request, and workload datasets instead of the UI-only people array.
- [x] Resolve gap: derive pending-request counts and all Pulse evidence values from the shared records.
- [x] Resolve gap: replace the hardcoded Pulse watchpoint title/count with the computed pending-request value.
- [x] Resolve gap: derive remaining Pulse context copy from shared operational records where feasible.

- [x] Harden gap: wire profile, attendance, leave, and payroll pages to tRPC/database data instead of hardcoded UI records.
- [x] Harden gap: implement or explicitly document Employee ID/email/password onboarding against the OAuth authentication path.
- [x] Harden gap: enforce leave overlap validation in the leave creation procedure and reflect HR decisions in employee-visible data immediately.
- [x] Harden gap: make selected HR employee context drive attendance, leave, payroll, and profile panes.
- [x] Harden gap: add explicit loading/error/empty states for each core data view.
- [x] Harden gap: create the promised 90-second presentation script.
- [x] Final integration: connect profile, attendance, leave, payroll, and pulse panels to tRPC/shared data in the shipped UI.
- [x] Final integration: propagate selected employee context across HR panes and refresh employee-facing leave state after review.
- [x] Final integration: add explicit per-view loading, error, and empty UI states.

- [ ] Release follow-up: connect shipped feature panels to tRPC/shared live data rather than static demo-only UI.
- [ ] Release follow-up: propagate selected employee and leave-review state across all HR and employee panes.
- [ ] Release follow-up: add explicit loading/error/empty states to every core view.
