# Dayflow — Feature and Offline Resilience Presentation Script

## Suggested runtime: 3–4 minutes

### 0:00–0:20 — Opening: one calm workspace

“Every workday, HR teams need to connect people, attendance, time-off, payroll, and planning. When those records live in separate places, the important signal is often hidden inside the chase. Dayflow brings the employee and HR experience into one calm, colorful workspace—so every workday feels more aligned.”

### 0:20–0:45 — Secure, organization-aware access

“Dayflow begins with a branded sign-in experience. A user selects the organization workspace they want to enter, then continues through the existing secure OAuth flow. The selected workspace is saved before authentication begins, and cancelled, denied, expired, or invalid sign-in attempts receive friendly recovery guidance instead of a technical dead end. Authenticated users are routed directly into the workspace.”

### 0:45–1:15 — The HR command center

“In the administrator view, the overview turns live records into four immediately useful signals: people at work, hours logged, time-off waiting for review, and payroll readiness. These values are calculated from scoped employee, attendance, leave, and payroll records through typed server procedures. The dashboard also includes an activity stream, attendance rhythm, quick actions, and Workforce Pulse context, so HR can move from a metric to the next helpful action.”

### 1:15–1:45 — Employee self-service

“Now we switch to the employee experience. Employees see their own profile, attendance, leave, and payroll information rather than the full team directory. They can check in and check out, view their workday records, request paid, sick, or unpaid leave with validated dates, and review salary components in a read-only view. The same workspace is role-aware, so the experience stays focused without exposing unrelated records.”

### 1:45–2:15 — People, attendance, leave, and payroll

“HR can search the people directory and open an employee context panel. Attendance views show weekly hours, recent records, calendar context, and team-level patterns. Leave views show request history, balances, pending reviews, and approval actions. Payroll keeps salary components and net pay visible and explainable, while readiness is calculated from the payroll records available for the current scope. Each workflow is connected to a visible record and a clear owner.”

### 2:15–2:40 — Workforce Pulse: signals, not scores

“Workforce Pulse is Dayflow’s differentiator. It uses operational evidence—attendance, approved time-off, and team workload—to surface transparent cues. It does not diagnose, rank, or profile people. The evidence stays beside the signal, and the recommended response remains a human decision for HR. Dayflow helps teams notice what may need attention without turning people into opaque scores.”

### 2:40–3:15 — Offline resilience

“Dayflow is also designed for imperfect connectivity. The latest successful dashboard payload is cached in the browser with a last-synced timestamp. If the network drops, the portal enters a clearly labeled read-only offline mode and continues showing the cached snapshot without pretending it is live. A compact top-bar indicator shows whether the workspace is Live, Syncing, or Offline.”

“When the server is temporarily unavailable, protected queries use bounded automatic retries. The dashboard tells the user when it is reconnecting, offers a manual Refresh or Retry action if the automatic attempt does not succeed, and keeps cached content visible where possible. When live data returns, Dayflow shows a success toast and a short visual restoration transition so the user knows the dashboard is current again.”

### 3:15–3:35 — Onboarding and personalization

“For first-time administrators, Dayflow presents a persistent setup checklist: confirm the workspace, add the first employee, connect attendance records, and review the time-off policy. Progress is saved locally and can be reopened from the portal. Users can also switch between light and dark themes, while the colorful gradient system, reduced-motion fallbacks, and responsive layouts keep the experience polished across devices.”

### 3:35–3:55 — Closing

“Dayflow connects the operational details of a workday with the context people teams need to act well. It is live when the network is available, honest when it is not, and explainable throughout. Dayflow moves HR from chasing records to seeing the next helpful action—without turning people into scores.”

## Demonstration cues

| Moment | Screen action | Message to emphasize |
|---|---|---|
| Opening | Start at the overview | One calm workspace for the employee-to-HR workflow. |
| HR metrics | Point to the four summary cards | Metrics are derived from live scoped records. |
| Directory | Open People and select an employee | HR gets context without losing role clarity. |
| Leave | Open a pending request and review it | The workflow has a clear owner and immediate status feedback. |
| Employee mode | Use the top-right role switcher | Employees see focused self-service views. |
| Attendance | Check in or check out | A daily action becomes a visible record. |
| Pulse | Open Workforce Pulse | Signals are evidence-backed cues, not hidden scores. |
| Offline | Demonstrate the offline banner or cached state | Cached data is labeled read-only and includes freshness context. |
| Recovery | Restore the connection or press Refresh | Automatic retries, manual retry, toast, and visual restoration close the loop. |
| Onboarding | Open Setup checklist | First-time administrators have a guided starting path. |

## Delivery note

The preview includes a deterministic workspace experience for demonstrations, while the application architecture supports authenticated, role-guarded live records through the Manus full-stack runtime. Present the offline mode as a resilience capability: it preserves continuity for viewing, while write actions should wait until the connection is restored.
